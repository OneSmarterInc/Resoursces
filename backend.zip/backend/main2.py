#copy of aviFlowai3
import os
import sqlite3
import threading
import time
from contextlib import closing
from typing import List
import threading
from datetime import datetime, timedelta, date
from pathlib import Path
from typing import List
import logging
import openai
from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends, Request, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from openai import OpenAI, OpenAIError
from pydantic import BaseModel, validator
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from kidapp_prompt import prompt_for_5_6_year_old, prompt_for_7_8_year_old, prompt_for_9_10_year_old

import base64
import io
import py_avataaars as pa
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from pathlib import Path
from datetime import datetime

import requests
import textwrap
import random
from gtts import gTTS
from moviepy.editor import *
from moviepy.video.fx.fadein import fadein
from moviepy.video.fx.fadeout import fadeout




app = FastAPI()

app.state.user_data = {}

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE","PATCH"],
    allow_headers=["*"],
)

# Model for login credentials
class Login(BaseModel):
    username: str
    password: str

# Model for chat message
class ChatMessage(BaseModel):
    user_input: str

# OpenAI API key
openai.api_key = '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'

# Model for adding a new user
class NewUser(BaseModel):
    username: str
    password: str
    dob: str 
    name: str # Change age to dob
    gender: str
    dreamCareer: str
    parrentPassword: str
    appliedthemes: str=None
    

    # Validate the dob field
    @validator('dob')
    def validate_dob(cls, v):
        try:
            datetime.strptime(v, '%Y-%m-%d')
        except ValueError:
            raise ValueError('Date of birth must be in the format YYYY-MM-DD')
        return v

# Function to calculate age from DOB
def calculate_age(dob: str) -> int:
    dob_date = datetime.strptime(dob, '%Y-%m-%d')
    today = datetime.today()
    age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
    return age


def create_database():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY,
                        username TEXT UNIQUE,
                        password TEXT,
                        parrentPassword TEXT,
                        dob TEXT,
                        name TEXT,
                        age INTEGER,
                        gender TEXT,
                        dreamCareer TEXT,
                        avatar TEXT,
                        story BOOLEAN DEFAULT 1,
                        question BOOLEAN DEFAULT 1,
                        quiz BOOLEAN DEFAULT 1,
                        joke BOOLEAN DEFAULT 1,
                        game BOOLEAN DEFAULT 1,
                        remainder BOOLEAN DEFAULT 1,
                        profile BOOLEAN DEFAULT 1,
                        AvatarDir TEXT
                        appliedthemes TEXT
                        time INTEGER DEFAULT 60,     
                        valid_time INTEGER DEFAULT 0,
                        real_time INTEGER
                    )''')
    conn.commit()
    conn.close()


def update_user_ages():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, dob FROM users")
    users = cursor.fetchall()
    for user in users:
        user_id, dob = user
        if dob:  # Check if dob is not None
            age = calculate_age(dob)
            cursor.execute("UPDATE users SET age = ? WHERE id = ?", (age, user_id))
    conn.commit()
    conn.close()

# Periodic task to update ages
def schedule_age_updates():
    while True:
        update_user_ages()
        time.sleep(5)  # Wait for 24 hours before running the update again

# Function to start the background task
@app.on_event("startup")
async def startup_event():
    threading.Thread(target=schedule_age_updates, daemon=True).start()
    
    
def insert_reminder(title: str, description: str, date: str, username: str):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO remaind (title, description, date, time, username)
    VALUES (?, ?, ?, ?, ?)
    ''', (title, description, date, "00:00", username))  # Time is set to "00:00" for birthday reminders
    conn.commit()
    conn.close()    

# Function to add a new user to the database
@app.post("/kids/v2/add_user/")
def add_user(new_user: NewUser):
    try:
        # Check if all required fields are provided
        # if not all(new_user.dict().values()):
        #     raise HTTPException(status_code=400, detail="All fields are required")
        required_fields = {key: value for key, value in new_user.dict().items() if key != "appliedthemes"}
        if not all(required_fields.values()):
            raise HTTPException(status_code=400, detail="All required fields must be provided")
        
        
        if new_user.password == new_user.parrentPassword:
            raise HTTPException(status_code=400, detail="Password and parent password must be different")
        
        
        age = calculate_age(new_user.dob)

        if age < 5 or age > 11:
            raise HTTPException(status_code=400, detail="User age must be between 5 and 11 years")

        conn = sqlite3.connect('kids_chat.db')
        cursor = conn.cursor()
        
        # Check if the username already exists
        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (new_user.username,))
        existing_user_count = cursor.fetchone()[0]
        if existing_user_count > 0:
            raise HTTPException(status_code=400, detail="Username already exists")
        
        # Insert the new user into the users table
        cursor.execute("INSERT INTO users (username, password, dob, name, age, gender, dreamCareer, parrentPassword, appliedthemes) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)",
                       (new_user.username, new_user.password, new_user.dob, new_user.name, age, new_user.gender, new_user.dreamCareer, new_user.parrentPassword, new_user.appliedthemes))
        
        # Insert the new user into the credits table with initial credits
        cursor.execute("INSERT INTO credits (username, credits) VALUES (?, ?)", (new_user.username, 0))  # Adjust initial credits as needed

        conn.commit()
        conn.close()

        # Insert birthday reminder
        insert_reminder("happy bday", "Birthday reminder", new_user.dob, new_user.username)

        return {"message": "User added successfully"}
    except HTTPException as e:
        raise e
    except Exception as e:
        print("Error:", e)  
        raise HTTPException(status_code=500, detail="Failed to add user to the database")


# Function to add the avatar column to the table if it doesn't exist
def add_avatar_column():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''PRAGMA table_info(users)''')
    columns = cursor.fetchall()
    column_names = [column[1] for column in columns]
    if 'avatar' not in column_names:
        cursor.execute('''ALTER TABLE users ADD COLUMN avatar TEXT''')
        conn.commit()
    conn.close()

# Create the database and table
create_database()

# Add the avatar column
add_avatar_column()

# Function to update the avatar URL based on the username
def update_user_avatar(username: str, avatar_url: str):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''UPDATE users SET avatar = ? WHERE username = ?''', (avatar_url, username))
    conn.commit()
    conn.close()

# Endpoint to handle updating the avatar URL
@app.post("/kids/v2/update_avatar/")
async def update_avatar(request: Request):
    username = request.query_params.get('username')
    avatar_url = request.query_params.get('avatar_url')
    if not username or not avatar_url:
        raise HTTPException(status_code=400, detail="Username and avatar_url are required")
    try:
        update_user_avatar(username, avatar_url)
        return {"success": "Avatar updated successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))




# Function to create the credits table
def create_credits_table():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS credits (
                        id INTEGER PRIMARY KEY,
                        username TEXT UNIQUE,
                        credits INTEGER DEFAULT 0
                    )''')
    conn.commit()
    conn.close()

# Initialize database tables
create_database()
create_credits_table()

# Function to fetch user data from database
def fetch_user_data(username):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    user_data = cursor.fetchone()
    conn.close()
    
    if user_data:
        return {'name': user_data[3], 'age': user_data[5], 'gender': user_data[6], 
                'dreamCareer': user_data[7]}
    else:
        return None

conn = sqlite3.connect('kids_chat.db')
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS streak (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    chat INTEGER DEFAULT 0,
    quiz INTEGER DEFAULT 0,
    question INTEGER DEFAULT 0,
    story INTEGER DEFAULT 0,
    joke INTEGER DEFAULT 0,
    date TEXT,
    total INTEGER DEFAULT 0,
    point INTEGER DEFAULT 0
)
''')

conn.commit()
conn.close()


conn = sqlite3.connect('kids_chat.db')
cursor = conn.cursor()

# Update the 'total' column to be the sum of the other columns
cursor.execute('''
UPDATE streak
SET total = chat + quiz + question + story + joke
''')

conn.commit()
conn.close()





class Login(BaseModel):
    username: str
    password: str

class ChatMessage(BaseModel):
    user_input: str  
# Initialize app state
app.state.user_data = {}
app.state.chat_histories = {} 

@app.post("/kids/v2/login/")
def login(login_data: Login, background_tasks: BackgroundTasks):
    try:
        conn = sqlite3.connect('kids_chat.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (login_data.username, login_data.password))
        user_data = cursor.fetchone()
        conn.close()

        if user_data:
            expected_fields = ['name', 'age', 'gender', 'dreamCareer']
            if len(user_data) >= len(expected_fields) + 4:
                user_data_dict = {field: user_data[i+4] for i, field in enumerate(expected_fields)}
                app.state.user_data[login_data.username] = user_data_dict
                app.state.user_data[login_data.username]["login_response"] = login_data.username
                return {"username": login_data.username}
            else:
                raise HTTPException(status_code=500, detail="User data incomplete or schema mismatch")
        else:
            raise HTTPException(status_code=401, detail="Invalid username or password")
    except Exception as e:
        print("Error:", e)
        raise HTTPException(status_code=500, detail="Internal Server Error")


# Function to create the daily transactions table
def create_daily_transactions_table():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS daily_transactions (
                        id INTEGER PRIMARY KEY,
                        username TEXT,
                        date TEXT,
                        credits_change INTEGER
                    )''')
    conn.commit()
    conn.close()

def create_history_table():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT ,
                        date TEXT ,
                        score INTEGER ,
                        field TEXT
                    )''')
    conn.commit()
    conn.close()

create_daily_transactions_table()
create_history_table()

def insert_into_history(username, score, field):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO history (username, date, score, field) 
                      VALUES (?, ?, ?, ?)''', (username, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), score, field))
    conn.commit()
    conn.close()

def get_current_credits(username):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute("SELECT credits FROM credits WHERE username = ?", (username,))
    current_credits = cursor.fetchone()[0]
    conn.close()
    return current_credits

def add_credits(username, credits_change):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE credits SET credits = credits + ? WHERE username = ?", (credits_change, username))
    conn.commit()
    conn.close()
    update_daily_transactions(username, credits_change)

def check_daily_limit(username, credits_change):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    today_date = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("SELECT SUM(credits_change) FROM daily_transactions WHERE username = ? AND date = ?", (username, today_date))
    total_credits_change = cursor.fetchone()[0] or 0
    conn.close()
    return abs(total_credits_change + credits_change) > 5

def update_daily_transactions(username, credits_change):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    today_date = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("INSERT INTO daily_transactions (username, date, credits_change) VALUES (?, ?, ?)",
                   (username, today_date, credits_change))
    cursor.execute("INSERT INTO history (username, date, score, field) VALUES (?, ?, ?, ?)",
                   (username, today_date, credits_change, "Chat"))
    cursor.execute("DELETE FROM history WHERE score=0")
    conn.commit()
    conn.close()

def send_message(username, user_input):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute("SELECT credits FROM credits WHERE username = ?", (username,))
    credits = cursor.fetchone()[0]
    updated_credits = credits

    try:
        prompt1 = f"Is the following message a polite phrase?: '{user_input}'\n"
        client = OpenAI(api_key='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')
        response1 = client.chat.completions.create(
            messages=[
                {"role": "system", "content": prompt1},
            ],
            max_tokens=10,
            temperature=1,
            model="gpt-4"
        )

        if "Yes" in response1.choices[0].message.content:
            credits_change = 1
            if not check_daily_limit(username, credits_change):
                add_credits(username, credits_change)
                updated_credits += credits_change
            else:
                print("Daily credit limit reached")

        prompt2 = f"Is the following message using bad words?: '{user_input}'\n"
        response2 = client.chat.completions.create(
            messages=[
                {"role": "system", "content": prompt2},
            ],
            max_tokens=10,
            temperature=1,
            model="gpt-4"
        )

        if "Yes" in response2.choices[0].message.content:
            credits_change = -1
            if not check_daily_limit(username, credits_change):
                add_credits(username, credits_change)
                updated_credits += credits_change
            else:
                print("Daily credit limit reached")

    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        conn.close()

    return updated_credits - credits



def get_db_connection():
    conn = sqlite3.connect('kids_chat.db')
    conn.row_factory = sqlite3.Row
    return conn

def create_chat_history_table():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS chat_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            date TEXT DEFAULT (DATE('now')),
            user_message TEXT,
            bot_response TEXT
        )
    ''')
    conn.commit()
    conn.close()

create_chat_history_table()

from datetime import date
import sqlite3

def update_streak_for_chat(username):
    today_date = date.today().isoformat()  # Get today's date in 'YYYY-MM-DD' format
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()

    # Count the number of messages the user has sent today
    cursor.execute('''
        SELECT COUNT(*) FROM chat_history
        WHERE username = ? AND date = ?
    ''', (username, today_date))
    message_count = cursor.fetchone()[0]

    if message_count > 3:
        # Update the chat column to 1 in the streak table for today
        cursor.execute('''
            UPDATE streak
            SET chat = 1
            WHERE username = ? AND date = ?
        ''', (username, today_date))

        # If there's no record for today in the streak table, insert a new one
        if cursor.rowcount == 0:
            cursor.execute('''
                INSERT INTO streak (username, chat, date)
                VALUES (?, 1, ?)
            ''', (username, today_date))

    conn.commit()
    conn.close()




def save_chat_message(username, user_message, bot_response):
    today_date = date.today().isoformat()  
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO chat_history (username, date, user_message, bot_response)
        VALUES (?, ?, ?, ?)
    ''', (username, today_date, user_message, bot_response))
    conn.commit()
    conn.close()

    # Update streak table after saving the message
    update_streak_for_chat(username)


class ChatHistoryResponse(BaseModel):
    user_message: str
    bot_response: str

# Function to get chat history from the database
def get_chat_history(username: str):
    connection = sqlite3.connect('kids_chat.db')
    cursor = connection.cursor()
    query = "SELECT user_message, bot_response FROM chat_history WHERE username = ?"
    cursor.execute(query, (username,))
    rows = cursor.fetchall()
    connection.close()
    return rows

@app.get("/kids/v2/chat_history/", response_model=list[ChatHistoryResponse])
async def read_chat_history(request: Request):
    username = request.query_params.get('username')
    if not username:
        raise HTTPException(status_code=400, detail="Username query parameter is required")
    
    results = get_chat_history(username)
    if not results:
        raise HTTPException(status_code=404, detail="No chat history found for the provided username")
    
    return [{"user_message": row[0], "bot_response": row[1]} for row in results]


def get_chat_history_by_date(username: str, start_date: str, end_date: str):
    connection = sqlite3.connect('kids_chat.db')
    cursor = connection.cursor()
    query = "SELECT user_message, bot_response FROM chat_history WHERE username = ? AND date BETWEEN ? AND ?"
    cursor.execute(query, (username, start_date, end_date))
    rows = cursor.fetchall()
    connection.close()
    return rows

@app.get("/kids/v2/chat_history_by_date/", response_model=list[ChatHistoryResponse])
async def read_chat_history_by_date(request: Request):
    username = request.query_params.get('username')
    start_date = request.query_params.get('start_date')
    end_date = request.query_params.get('end_date')
    
    if not username:
        raise HTTPException(status_code=400, detail="Username query parameter is required")
    if not start_date or not end_date:
        raise HTTPException(status_code=400, detail="Start date and end date query parameters are required")
    
    results = get_chat_history_by_date(username, start_date, end_date)
    if not results:
        raise HTTPException(status_code=404, detail="No chat history found for the provided username and date range")
    
    return [{"user_message": row[0], "bot_response": row[1]} for row in results]





DATABASE = 'kids_chat.db'

def get_db():
    conn = sqlite3.connect(DATABASE, check_same_thread=False)  #
    try:
        yield conn
    finally:
        conn.close()

@app.put("/kids/v2/update_user/")
async def update_user(
    request: Request,
    db: sqlite3.Connection = Depends(get_db)
):
    
    username = request.query_params.get('username')
    column_name = request.query_params.get('column_name')
    value = request.query_params.get('value')

    
    if username is None or column_name is None or value is None:
        raise HTTPException(status_code=400, detail="Missing required query parameters")

    try:
        value = int(value)
    except ValueError:
        raise HTTPException(status_code=400, detail="Value must be an integer (0 or 1)")

    
    if value not in [0, 1]:
        raise HTTPException(status_code=400, detail="Value must be 0 or 1")
    
    
    valid_columns = ["story", "question", "quiz", "joke", "game", "remainder", "profile"]
    if column_name not in valid_columns:
        raise HTTPException(status_code=400, detail="Invalid column name")
    
    
    cursor = db.cursor()
    cursor.execute(f"UPDATE users SET {column_name} = ? WHERE username = ?", (value, username))
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    db.commit()
    return {"message": "updated successfully"}




# @app.post("/kids/v2/chat/")
# async def chat(request: Request, chat_message: ChatMessage):
#     username = request.query_params.get('username')
#     if not username:
#         raise HTTPException(status_code=400, detail="Username query parameter is required")

#     user_data = app.state.user_data.get(username)
#     if not user_data or 'age' not in user_data:
#         raise HTTPException(status_code=404, detail="User data not found or incomplete")

#     user_input = chat_message.user_input.lower()
#     chat_history = app.state.chat_histories.get(username, [])
#     chat_history.append(user_input)
#     app.state.chat_histories[username] = chat_history[-70:]

#     prompt = get_prompt_based_on_age(user_data['age'])
#     response = ask_gpt(prompt, user_input, user_data, chat_history)
#     filtered_response = filter_response(response)
#     credits_change = send_message(username, user_input)

#     save_chat_message(username, user_input, filtered_response)

#     return {"bot_response": filtered_response, "credit_change": credits_change}



# @app.post("/kids/v2/chat/")
# async def chat(request: Request, chat_message: ChatMessage):
#     username = request.query_params.get('username')
#     if not username:
#         raise HTTPException(status_code=400, detail="Username query parameter is required")

#     user_data = app.state.user_data.get(username)
#     if not user_data or 'age' not in user_data:
#         raise HTTPException(status_code=404, detail="User data not found or incomplete")

#     user_input = chat_message.user_input.lower()
    
#     # Retrieve chat history, or initialize it if not found
#     chat_history = app.state.chat_histories.get(username, [])
    
#     # Add user input to chat history
#     chat_history.append({"role": "user", "content": user_input})
    
#     # Limit chat history to the last 70 messages
#     app.state.chat_histories[username] = chat_history[-70:]

#     # Extract the content (just the messages) from chat_history
#     conversation_history = [entry['content'] for entry in chat_history]

#     prompt = get_prompt_based_on_age(user_data['age'])
#     response = ask_gpt(prompt, user_input, user_data, conversation_history)  # Use extracted content here
#     filtered_response = filter_response(response)
    
#     # Add bot response to chat history
#     chat_history.append({"role": "bot", "content": filtered_response})
    
#     # Save updated chat history, limiting to the last 70 messages
#     app.state.chat_histories[username] = chat_history[-70:]

#     credits_change = send_message(username, user_input)
    
#     save_chat_message(username, user_input, filtered_response)

#     return {"bot_response": filtered_response, "credit_change": credits_change}




import asyncio
from fastapi import HTTPException, Request
from typing import Any

@app.post("/kids/v2/chat/")
async def chat(request: Request, chat_message: ChatMessage):
    username = request.query_params.get('username')
    if not username:
        raise HTTPException(status_code=400, detail="Username query parameter is required")

    user_data = app.state.user_data.get(username)
    if not user_data or 'age' not in user_data:
        raise HTTPException(status_code=404, detail="User data not found or incomplete")

    user_input = chat_message.user_input.lower()
    
    # Retrieve chat history, or initialize it if not found
    chat_history = app.state.chat_histories.get(username, [])
    
    # Add user input to chat history
    chat_history.append({"role": "user", "content": user_input})
    
    # Limit chat history to the last 70 messages
    app.state.chat_histories[username] = chat_history[-70:]

    # Extract the content (just the messages) from chat_history
    conversation_history = [entry['content'] for entry in chat_history]

    prompt = get_prompt_based_on_age(user_data['age'])

    response = None
    retries = 3
    for attempt in range(retries):
        try:
            # Use asyncio.wait_for to enforce a 10-second timeout
            response = await asyncio.wait_for(
                ask_gpt(prompt, user_input, user_data, conversation_history), 
                timeout=10
            )
            break  
        except asyncio.TimeoutError:
            if attempt < retries - 1:
                # Log the retry attempt if needed
                print(f"Retry {attempt + 1}/{retries} due to timeout.")
            else:
                # If this was the last retry, handle the failure
                raise HTTPException(status_code=504, detail="Request timed out after multiple attempts.")

    filtered_response = filter_response(response)
    
    # Add bot response to chat history
    chat_history.append({"role": "bot", "content": filtered_response})
    
    # Save updated chat history, limiting to the last 70 messages
    app.state.chat_histories[username] = chat_history[-70:]

    credits_change = send_message(username, user_input)
    
    save_chat_message(username, user_input, filtered_response)

    return {"bot_response": filtered_response, "credit_change": credits_change}







@app.get("/kids/v2/audio/")
def get_audio():
    speech_file_path = Path(__file__).parent / "speech.mp3"
    if not speech_file_path.exists():
        raise HTTPException(status_code=404, detail="Audio file not found")
    return FileResponse(speech_file_path, media_type="audio/mp3")




# Helper function to determine prompt based on user's age
def get_prompt_based_on_age(age):
 
    if 5 <= age <= 6:
        return prompt_for_5_6_year_old
    elif 7 <= age <= 8:
        return prompt_for_7_8_year_old
    elif 9 <= age <= 15:
        return prompt_for_9_10_year_old
    else:
        raise HTTPException(status_code=400, detail="Invalid age group")

async def ask_gpt(prompt: str, user_input: str, knowledge_base: dict, chat_history: list) -> str:
# def ask_gpt(prompt, user_input, knowledge_base, chat_history):
    try:

       
        knowledge_prompt = prompt + " ".join([f"'{k}': '{v}', " for k, v in knowledge_base.items()])
        chat_prompt = knowledge_prompt + '\n'.join(chat_history[-30:])  
        #print(chat_prompt)
        
        client = OpenAI(
        api_key = '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' #os.environ.get('OPENAI_API_KEY')
        )
        response = client.chat.completions.create(
        
        # Initialize the messages list with the system and user messages
        messages = [
            {"role": "system", "content": chat_prompt},
            {"role": "user", "content": user_input}
        ],
        max_tokens=150,  
        temperature=1,
        model="gpt-4o"
        ) 
        return response.choices[0].message.content
        
    except Exception as e:
        # Log the exception for debugging
        print(f"An error occurred: {str(e)}")
        return "I'm sorry, an error occurred."





def filter_response(response):
    if "bad word" in response.lower():
        return "I'm sorry, I can't say that."
    return response


class Question(BaseModel):
    text: str
    answer: str


#asked_questions = []

def get_correct_answer(question):


    client = OpenAI(
        api_key = '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' 
        )
    response = client.chat.completions.create(
        
   
    messages = [
        {"role": "system", "content": f"Question: {question}\nAnswer:"},
        
    ],
    max_tokens=100,  
    temperature=0,
    model="gpt-4"
        ) 
    return response.choices[0].message.content
        
asked_questions = set()

def generate_questions(topic, question_answers, age):
    while True:
        if 5 <= age <= 6:
            prompt = f"generate a multiple-choice question for 5-6 year old kid covering different areas of {topic} concepts suitable for young children, such as {topic} height, colors, shapes, numbers, behaviour, size, etc., and basic vocabulary. To ensure variety and prevent repetition, the question must be very simple."
        elif 7 <= age <= 8:
            prompt = f"generate a multiple-choice question for 7-8 year old kid covering different areas of {topic} concepts suitable for young children, such as {topic} height, colors, shapes, numbers, behaviour, size, etc., and basic vocabulary. To ensure variety and prevent repetition."
        elif 9 <= age <= 11:
            prompt = f"generate a multiple-choice question for 9-11 year old kid covering different areas of {topic} concepts suitable for young children, such as {topic} height, colors, shapes, numbers, behaviour, size, etc., and basic vocabulary. To ensure variety and prevent repetition. Use some challenging words in the question."
        else:
            raise ValueError("Age must be between 5 and 11 years old.")

        client = OpenAI(
            api_key='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'
        )
        response = client.chat.completions.create(
            messages=[
                {"role": "system", "content": prompt},
            ],
            max_tokens=150,
            temperature=1,
            model="gpt-4"
        )
        question = response.choices[0].message.content

        if is_valid_question(question) and not is_similar_to_previous(question):
            correct_answer = get_correct_answer(question)
            asked_questions.add(question)
            question_answers[question] = correct_answer
            return question, correct_answer

def is_similar_to_previous(new_question):
    if not asked_questions:
        return False
    vectorizer = TfidfVectorizer().fit(list(asked_questions))
    new_question_vec = vectorizer.transform([new_question])
    similarity_scores = cosine_similarity(new_question_vec, vectorizer.transform(list(asked_questions)))[0]
    return any(score > 0.7 for score in similarity_scores)

def is_valid_question(question):
    return len(question.split()) > 3 

# @app.post("/kids/v2/quiz/{topic}/{age}")
# async def start_quiz(topic: str, age: int):
#     global asked_questions
#     asked_questions.clear()
#     question_answers = {}
#     questions = []
#     try:
#         while len(questions) < 5:  # Generate 5 unique questions
#             question_text, correct_answer = generate_questions(topic, question_answers, age)
#             questions.append({"text": question_text, "answer": correct_answer})
#         random.shuffle(questions)  # Shuffle the questions to randomize their order
#         return {"questions": questions}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))



@app.post("/kids/v2/quiz/{topic}/{age}")
async def start_quiz(topic: str, age: int):
    global asked_questions
    asked_questions.clear()
    question_answers = {}
    questions = []
    
    try:
        async def generate_quiz_questions():
            while len(questions) < 5:  # Generate 5 unique questions
                question_text, correct_answer = generate_questions(topic, question_answers, age)
                print("_________________")
                questions.append({"text": question_text, "answer": correct_answer})
            random.shuffle(questions)  # Shuffle the questions to randomize their order
            return {"questions": questions}

        # Set the timeout to 30 secondsFF
        result = await asyncio.wait_for(generate_quiz_questions(), timeout=60.0)
        return result

    except asyncio.TimeoutError:
        raise HTTPException(status_code=408, detail="Request timed out. Please try again.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



class LoginResponse(BaseModel):
    username: str

# Define the data model for the quiz submission
class QuizSubmission(BaseModel):
    username: str
    score: int


# Function to create the SQLite database table
def create_table():
    conn = sqlite3.connect('kids_chat.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS quiz_submissions
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT,
                  score INTEGER,
                  submission_date TEXT)''')
    conn.commit()
    conn.close()

def create_user_scores_table():
    conn = sqlite3.connect('kids_chat.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS quiz_submissions1
                 (username TEXT PRIMARY KEY,
                  score INTEGER)''')
    conn.commit()
    conn.close()

# Create the user_scores table when the application starts
create_user_scores_table()

class QuizSubmission:
    def __init__(self, username, score):
        self.username = username
        self.score = score

# Ensure the quiz_submissions and user_scores tables are created
create_table()
create_user_scores_table()





@app.post("/kids/v2/submit_quiz/")
async def submit_quiz(request: Request):
    username = request.query_params.get("username")
    if not username:
        raise HTTPException(status_code=400, detail="Username is required")
    
    score_str = request.query_params.get("score")
    if not score_str:
        raise HTTPException(status_code=400, detail="Score is required")
    
    try:
        score = int(score_str)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid score")
    
    # Get current date
    today = date.today().isoformat()
    
    # Check if the user has already submitted a score today
    conn = sqlite3.connect('kids_chat.db')
    c = conn.cursor()
    c.execute("SELECT id FROM quiz_submissions WHERE username=? AND submission_date=?",
              (username, today))
    existing_submission = c.fetchone()
    conn.close()
    
    if existing_submission:
        raise HTTPException(status_code=400, detail="You have already submitted a score today")
    
    # Insert the submission into the quiz_submissions table
    conn = sqlite3.connect('kids_chat.db')
    c = conn.cursor()
    c.execute("INSERT INTO quiz_submissions (username, score, submission_date) VALUES (?, ?, ?)",
              (username, score, today))
    c.execute("INSERT INTO history (username, score, date, field) VALUES (?, ?, ?, ?)",
              (username, score, today, "quiz"))

    conn.commit()

    # Update the user_scores table
    c.execute("SELECT score FROM quiz_submissions1 WHERE username=?", (username,))
    row = c.fetchone()
    if row:
        new_total_score = row[0] + score
        c.execute("UPDATE quiz_submissions1 SET score=? WHERE username=?", (new_total_score, username))
    else:
        c.execute("INSERT INTO quiz_submissions1 (username, score) VALUES (?, ?)", (username, score))

    conn.commit()

    # Update the streak table
    c.execute("SELECT * FROM streak WHERE username=? AND date=?", (username, today))
    streak_record = c.fetchone()

    if streak_record:
        c.execute("UPDATE streak SET quiz = 1 WHERE username=? AND date=?", (username, today))
    else:
        c.execute("INSERT INTO streak (username, quiz, date) VALUES (?, ?, ?)", (username, 1, today))

    conn.commit()
    conn.close()
    
    return {"message": "Quiz submitted successfully"}















def get_age_group(age):
    if 5 <= age <= 6:
        return "5-6"
    elif 7 <= age <= 8:
        return "7-8"
    elif 9 <= age <= 11:
        return "9-11"
    else:
        raise HTTPException(status_code=400, detail="Invalid age group")

# Function to generate the question based on age and topic
def get_question_based_on_age(age, topic):
    if 5 <= age <= 6:
        return f"Generate a Guessing game question for 5-6 year old kid with 2 hints about {topic} for kids. Use very simple words in the question."
    elif 7 <= age <= 8:
        return f"Generate a Guessing game question for 7-8 year old kid with 2 hints about {topic} for kids."
    elif 9 <= age <= 11:
        return f"Generate a Guessing game question for 9-11 year old kid with 2 hints about {topic} for kids. Use  difficult words in the question."
    else:
        raise HTTPException(status_code=400, detail="Invalid age group")

def generate_question(age, topic):
    prompt = get_question_based_on_age(age, topic)
    client = OpenAI(
        api_key='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'  # Replace with your actual API key
    )
    response = client.chat.completions.create(
        messages=[
            {"role": "system", "content": prompt},
        ],
        max_tokens=100,
        temperature=0,
        model="gpt-4"
    )
    question = response.choices[0].message.content
    return question

def provide_explanation(generated_content):
    client = OpenAI(
        api_key='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'  # Replace with your actual API key
    )
    response = client.chat.completions.create(
        messages=[
            {"role": "system", "content": f"Question: {generated_content}\nCorrect Answer :"},
        ],
        max_tokens=100,
        temperature=0,
        model="gpt-4"
    )
    answer = response.choices[0].message.content
    return answer

def get_daily_topic():
    tomorrow = datetime.now() + timedelta(days=1)  # Adjusted to get the next day's date
    topic_index = tomorrow.day % 30  # Assuming there are 4 topics in total
    topics = ["Animals", "Fruits and Vegetables", "Colors", "Famous Cartoons or Characters", "Shapes", 
    "Numbers", "Sports", "Musical Instruments", "Vehicles", "Weather",
    "Planets", "Superheroes", "Insects", "Pets", "Earth", 
    "Fairy Tale Characters", "Dinosaurs", "Holidays", "Ocean Creatures", "Magical Creatures",
    "Famous Landmarks", "tree",  "india","UK", "USA", 
    "Modes of Transportation", "School Supplies", "Household Items", "Famous Explorers", "Types of Candy"]
    return topics[topic_index]

# @app.get("/kids/v2/generate-question/")
# async def generate_question_endpoint(age: int):
#     initialize_database()  # Initialize the database before any operation
#     today = datetime.today().strftime('%Y-%m-%d')
#     age_group = get_age_group(age)

#     question, correct_answer = load_question_from_database(today, age_group)

#     if not question:
#         topic = get_daily_topic()
#         print(f"Generating question for topic: {topic} and age group: {age_group}")

#         while True:
#             question = generate_question(age, topic)
#             if not check_if_question_exists(question, age_group):
#                 break

#         correct_answer = provide_explanation(question)
#         print(f"Saving question: {question} with answer: {correct_answer}")
#         save_question_to_database(today, question, correct_answer, age_group)

#     return {"question": question, "answer": correct_answer}






import asyncio
from datetime import datetime, timedelta

@app.get("/kids/v2/generate-question/")
async def generate_question_endpoint(age: int):
    initialize_database()  # Initialize the database before any operation
    today = datetime.today().strftime('%Y-%m-%d')
    age_group = get_age_group(age)

    # Try loading the question from the database
    question, correct_answer = load_question_from_database(today, age_group)

    # If no question found, start generating one
    if not question:
        topic = get_daily_topic()
        print("question topic ", topic)
        print(f"Generating question for topic: {topic} and age group: {age_group}")
        
        start_time = datetime.now()  # Start tracking time

        while True:
            question = generate_question(age, topic)
            
            if not check_if_question_exists(question, age_group):
                correct_answer = provide_explanation(question)
                print(f"Saving question: {question} with answer: {correct_answer}")
                save_question_to_database(today, question, correct_answer, age_group)
                break

            # If 1 minute has passed, retry the process
            if datetime.now() - start_time > timedelta(minutes=1):
                print("1 minute exceeded, retrying question generation...")
                await asyncio.sleep(1)  # Small pause before retrying
                return await generate_question_endpoint(age)  # Re-run the endpoint

    return {"question": question, "answer": correct_answer}



def initialize_database():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    try:
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,
                question TEXT,
                answer TEXT,
                age_group TEXT,
                UNIQUE(date, age_group)
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS question_score (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                score INTEGER,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        conn.commit()
    except sqlite3.Error as e:
        print(f"Error initializing database: {e}")
    
    finally:
        conn.close()

initialize_database()

def save_question_to_database(date, question, answer, age_group):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO daily_questions (date, question, answer, age_group) VALUES (?, ?, ?, ?)
    ''', (date, question, answer, age_group))
    conn.commit()
    conn.close()

def load_question_from_database(date, age_group):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT question, answer FROM daily_questions WHERE date = ? AND age_group = ?
    ''', (date, age_group))
    row = cursor.fetchone()
    conn.close()
    if row:
        print("Question retrieved:", row[0])
        print("Answer retrieved:", row[1])
        return row[0], row[1]
    else:
        print("No question found for the given date and age group.")
        return None, None

def check_if_question_exists(question, age_group):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT COUNT(*) FROM daily_questions WHERE question = ? AND age_group = ?
    ''', (question, age_group))
    count = cursor.fetchone()[0]
    conn.close()
    return count > 0

def initialize_database111():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    
    # Create table for storing individual scores
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS question_score (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            score INTEGER NOT NULL,
            date TEXT NOT NULL
        )
    """)
    
    # Create table for storing the sum of scores
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS question_score1 (
            username TEXT PRIMARY KEY,
            score INTEGER NOT NULL
        )
    """)
    
    conn.commit()
    conn.close()

def check_score_exists(username: str, today: str) -> bool:
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM question_score WHERE username = ? AND date = ?", (username, today))
    count = cursor.fetchone()[0]
    conn.close()
    return count > 0

def update_total_score(username: str, score: int):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    
    cursor.execute("SELECT score FROM question_score1 WHERE username = ?", (username,))
    result = cursor.fetchone()
    
    if result:
        total_score = result[0] + score
        cursor.execute("UPDATE question_score1 SET score = ? WHERE username = ?", (total_score, username))
    else:
        cursor.execute("INSERT INTO question_score1 (username, score) VALUES (?, ?)", (username, score))
    
    conn.commit()
    conn.close()


@app.get("/kids/v2/provide-explanation/")
async def provide_explanation_endpoint(request: Request):
    initialize_database111()
    today = datetime.now().strftime('%Y-%m-%d')
    age = request.query_params.get("age")
    
    if not age:
        raise HTTPException(status_code=400, detail="Age not provided")
    
    age = int(age)
    age_group = get_age_group(age)
    print(f"Fetching question for date: {today} and age group: {age_group}")
    
    _, correct_answer = load_question_from_database(today, age_group)
    print(f"Fetched answer: {correct_answer}")

    if not correct_answer:
        return {"error": "No question generated for today"}

    try:
        username = request.query_params.get("username")
        score = request.query_params.get("score")

        if not username:
            raise HTTPException(status_code=400, detail="Username not provided")
        
        if score:
            try:
                score = int(score)
            except ValueError:
                raise HTTPException(status_code=400, detail="Score must be an integer")

            # Check if score already exists for today and this user
            if check_score_exists(username, today):
                return {"explanation": correct_answer, "message": "Score already submitted for today"}

            # Insert score into the database
            conn = sqlite3.connect('kids_chat.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO question_score (username, score, date) VALUES (?, ?, ?)", (username, score, today))
            cursor.execute("INSERT INTO history (username, score, date, field) VALUES (?, ?, ?, ?)",
                        (username, score, today, "question"))

            cursor.execute("SELECT * FROM streak WHERE username = ? AND date = ?", (username, today))
            streak_record = cursor.fetchone()

            if streak_record:
                cursor.execute("UPDATE streak SET question = 1 WHERE username = ? AND date = ?", (username, today))
            else:
                cursor.execute("INSERT INTO streak (username, question, date) VALUES (?, ?, ?)", (username, 1, today))

            conn.commit()
            conn.close()

            # Update the total score for the user
            update_total_score(username, score)

        return {"explanation": correct_answer}

    except Exception as e:
        print("Error:", e)
        raise HTTPException(status_code=500, detail="Internal Server Error")










def get_story_based_on_age(age, topic,name):
    if 5 <= age <= 6:
        return f"Generate a meaningful short story on {name} with a good lesson on {topic} for kids. Use very simple words. for story use upto 100 words."
    elif 7 <= age <= 8:
        return f"Generate a meaningful story on {name} with a good lesson on {topic} for kids. for story used upto 125 words."
    elif 9 <= age <= 11:
        return f"Generate a meaningful story on {name} with a good lesson on {topic} for kids. for story used upto 175 words."
    else:
        raise HTTPException(status_code=400, detail="Invalid age group")

def generate_story(age, topic,name):
    prompt = get_story_based_on_age(age, topic,name)
    client = OpenAI(api_key='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')
    response = client.chat.completions.create(
        messages=[{"role": "system", "content": prompt}],
        max_tokens=500,
        temperature=1,
        model="gpt-4o"
    )
    story = response.choices[0].message.content
    return story

def generate_url(story):
    api_key = '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'
    client = OpenAI(api_key=api_key)
    response = client.images.generate(
        model="dall-e-3",
        prompt=story,
        size="1024x1024",
        quality="standard",
        n=1,
    )
    image_url = response.data[0].url
    return image_url

def get_daily_topic2():
    tomorrow = datetime.now() + timedelta(days=1)
    topic_index = tomorrow.day % 30
    topics = ["Adventure", "Friendship", "Magic", "Bravery", "Discovery", "Imagination", "Dreams", "Courage", "Mystery", "Journey",
    "Teamwork", "Kindness", "Wonder", "Exploration", "Creativity", "Happiness", "Curiosity", "Wisdom", "Fun", "Growth",
    "Challenge", "Harmony", "Hope", "Learning", "Trust", "Joy", "Unity", "Adventure", "Dreams", "Discovery"]

    return topics[topic_index]

def get_kid_name():
    tomorrow = datetime.now() + timedelta(days=1)
    topic_index = tomorrow.day % 30
    kid_names = [
        "Aiden", "Bella", "Charlie", "Daisy", "Ethan", "Fiona", "George", "Hannah", 
        "Isaac", "Julia", "Kevin", "Lily", "Mason", "Nina", "Oscar", "Piper", 
        "Quinn", "Riley", "Sophie", "Tyler", "Uma", "Violet", "Wyatt", "Xander", 
        "Yara", "Zoe", "Abby", "Ben", "Chloe", "David"
    ]
    return kid_names[topic_index]


def initialize_database2():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    try:
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_story (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,
                age_group TEXT,
                story TEXT,
                image_url TEXT,
                video_path TEXT,
                UNIQUE(date, age_group)
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS story_score (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,
                username TEXT,
                score INTEGER,
                UNIQUE(date, username)
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS story_score1 (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                score INTEGER
            )
        ''')
        conn.commit()
    except sqlite3.Error as e:
        print(f"Error initializing database: {e}")
    finally:
        conn.close()

def save_story_to_database(date, age_group, story, image_url):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO daily_story (date, age_group, story, image_url)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(date, age_group) DO UPDATE SET story = ?, image_url = ?
    ''', (date, age_group, story, image_url, story, image_url))
    conn.commit()
    conn.close()

def load_story_from_database(date, age_group):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT story, video_path FROM daily_story WHERE date = ? AND age_group = ?
    ''', (date, age_group,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return row[0], row[1]  # Return both story and image_url
    else:
        return None, None  # Return None for both if no story is found
    


initialize_database2()
def check_if_story_exists(date, age_group):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT COUNT(*) FROM daily_story WHERE date = ? AND age_group = ?
    ''', (date, age_group,))
    count = cursor.fetchone()[0]
    conn.close()
    return count > 0

def check_if_user_submitted_score1(date, username):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT COUNT(*) FROM story_score WHERE date = ? AND username = ?
    ''', (date, username))
    count = cursor.fetchone()[0]
    conn.close()
    return count > 0

def save_story_score_to_database(date, username, score):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO story_score (date, username, score) VALUES (?, ?, ?)
        ''', (date, username, score))
        cursor.execute("INSERT INTO history (username, score, date, field) VALUES (?, ?, ?, ?)",
                       (username, score, date, "story"))
        conn.commit()

        cursor.execute('''
            INSERT INTO story_score1 (username, score) VALUES (?, ?)
            ON CONFLICT(username) DO UPDATE SET score = score + ?
        ''', (username, score, score))
        conn.commit()
    except sqlite3.IntegrityError:
        print(f"Score for {username} on {date} already exists.")
    finally:
        conn.close()

def get_total_score(username):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT score FROM story_score1 WHERE username = ?
    ''', (username,))
    total_score = cursor.fetchone()
    conn.close()
    if total_score:
        return total_score[0]
    else:
        return 0











# OpenAI API setup
api_key = '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'  # Replace with your actual OpenAI API key
openai.api_key = api_key









output_dir = "generated_content"
if not os.path.exists(output_dir):
    os.mkdir(output_dir)

# Function to generate images with context
def generate_images(sentences, wait_time=600):
    image_paths = []
    last_sentence = ""  # Get the last sentence for context
    
    for i, sentence in enumerate(sentences):
        last_sentence += f"{sentence} "
        print(f"Generating image for sentence {i + 1}/{len(sentences)}...")
        start_time = time.time()
        while True:
            try:
                # Combine the current sentence with the last sentence for context
                prompt = (f"An illustration of a scene from a storybook without any text. "
                          f"The scene should depict images without any text or words: {sentence}. "
                          f"Consider the context of the final scene where {last_sentence}. "
                          f"The image should not contain any words or text.")
                
                response = openai.images.generate(
                    prompt=prompt,
                    n=1,
                    model='dall-e-3',
                    size="1024x1024"
                )
                
                image_url = response.data[0].url
                image_filename = f"image_{i + 1}_{random.randint(1000, 9999)}.jpg"
                image_path = os.path.join(output_dir, image_filename)
                
                # Download and save the image
                image_data = requests.get(image_url).content
                with open(image_path, "wb") as image_file:
                    image_file.write(image_data)
                
                image_paths.append(image_path)
                break

            except Exception as e:
                elapsed_time = time.time() - start_time
                print(f"Error occurred: {e}. Retrying... (Elapsed time: {elapsed_time:.2f}s)")

                if elapsed_time > wait_time:
                    print(f"Skipping sentence {i + 1} after {wait_time} seconds.")
                    break

                time.sleep(2)  # Small pause before retrying
        
        # Optional: Pause between API calls to avoid rate limits
        time.sleep(2)
    
    print("Image generation complete.")
    return image_paths





import os
import boto3

# Define the output directory for audio files
output_dir = "generated_content"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Initialize Polly client with your AWS credentials
polly_client = boto3.Session(
                aws_access_key_id='AKIA4JJHQBORKLVC7W5B',
                aws_secret_access_key='9LkxFuZ3slR/jyEuHkhgc4Oax5KEVMifdX+WNO3P',
                region_name='us-west-2').client('polly')

# Function to convert text to audio using Amazon Polly
def convert_text_to_audio(sentences):
    audio_paths = []
    
    for i, sentence in enumerate(sentences):
        sentence=f"<speak><prosody rate='medium'> {sentence}    </prosody> </speak>"
        print(f"Converting sentence {i + 1}/{len(sentences)} to audio...")
        
        # Convert the sentence to speech using Amazon Polly
        response = polly_client.synthesize_speech(
            Text=sentence,
            OutputFormat='mp3',
            VoiceId='Kevin',  # Use a British English voice
            Engine='neural',  # Use the neural engine for better quality
            TextType='ssml'  # Use 'Justin' for a child-friendly voice
        )
        
        # Save the audio file
        audio_filename = f"audio_{i + 1}.mp3"
        audio_path = os.path.join(output_dir, audio_filename)
        with open(audio_path, 'wb') as audio_file:
            audio_file.write(response['AudioStream'].read())
        
        audio_paths.append(audio_path)
    
    print("Audio conversion complete.")
    return audio_paths














# output_dir = "generated_content"
# # Function to convert text to audio
# def convert_text_to_audio(sentences):
#     audio_paths = []
#     for i, sentence in enumerate(sentences):
#         print(f"Converting sentence {i + 1}/{len(sentences)} to audio...")
#         tts = gTTS(sentence, lang='en')
#         audio_filename = f"audio_{i + 1}.mp3"
#         audio_path = os.path.join(output_dir, audio_filename)
#         tts.save(audio_path)
#         audio_paths.append(audio_path)
    
#     print("Audio conversion complete.")
#     return audio_paths

# Function to create video clips
def create_video_clips(image_paths, audio_paths):
    video_clips = []
    for i, (image_path, audio_path) in enumerate(zip(image_paths, audio_paths)):
        print(f"Creating video clip {i + 1}/{len(image_paths)}...")
        audio = AudioFileClip(audio_path)
        image = ImageClip(image_path, duration=audio.duration)
        video = image.set_audio(audio)
        video = fadein(video, 1).fadeout(1)
        video.fps = 24
        video_clips.append(video)
    
    print("Video clips creation complete.")
    return video_clips

# Function to concatenate videos
def concatenate_videos(video_clips, output_video_path):
    print("Concatenating video clips into final video...")
    final_video = concatenate_videoclips(video_clips, method="compose")
    final_video.write_videofile(output_video_path, codec="libx264", audio_codec='aac')
    print(f"Final video saved at: {output_video_path}")
    return output_video_path

# Function to clean up temporary audio files
def clean_up(audio_paths):
    print("Cleaning up temporary audio files...")
    for audio_path in audio_paths:
        os.remove(audio_path)
    print("Cleanup complete.")




from datetime import datetime, timedelta
import glob


def delete_all_images(output_dir):
    # List of common image file extensions
    image_extensions = ["*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp", "*.tiff", "*.webp"]

    # Loop through all the image extensions and delete the matched files
    for ext in image_extensions:
        image_files = glob.glob(os.path.join(output_dir, ext))
        for image_file in image_files:
            try:
                os.remove(image_file)
                print(f"Deleted: {image_file}")
            except Exception as e:
                print(f"Error deleting {image_file}: {e}")

    print("All images in the directory have been deleted.")



def delete_previous_day_video(age_group):
    age_group_dir = os.path.join(output_dir, age_group)
    
    # Calculate the previous day's date
    previous_day = (datetime.today() - timedelta(days=3)).strftime('%Y-%m-%d')

    
    # Find all videos in the directory
    video_pattern = os.path.join(age_group_dir, f"{previous_day}_story_video.mp4")
    for video_file in glob.glob(video_pattern):
        try:
            os.remove(video_file)
            print(f"Deleted previous day's video: {video_file}")
        except OSError as e:
            print(f"Error deleting file {video_file}: {e}")

def generate_video_from_story(story, age_group):
    # Delete the previous day's video
    
    
    # Create a directory for the specific age group if it doesn't exist
    age_group_dir = os.path.join(output_dir, age_group)
    if not os.path.exists(age_group_dir):
        os.makedirs(age_group_dir)
    
    # Break the story into sentences for image and audio generation
    sentences = textwrap.wrap(story, width=80)
    
    # Generate images for each sentence
    image_paths = generate_images(sentences)
    
    # Convert sentences to audio
    audio_paths = convert_text_to_audio(sentences)
    
    # Create video clips from images and audio
    video_clips = create_video_clips(image_paths, audio_paths)
    
    # Concatenate video clips into a final video
    video_filename = f"{datetime.today().strftime('%Y-%m-%d')}_story_video.mp4"
    video_path = os.path.join(age_group_dir, video_filename)
    concatenate_videos(video_clips, video_path)
    
    # Clean up temporary audio files
    clean_up(audio_paths)
    delete_all_images(output_dir)
    delete_previous_day_video(age_group)
    return video_path






def update_video_path_in_database(date, age_group, video_path):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    
    if age_group == "5-6":
        cursor.execute('''
            UPDATE daily_story
            SET video_path = ?
            WHERE date = ? AND age_group = ?
        ''', (video_path, date, age_group))
    elif age_group == "7-8":
        cursor.execute('''
            UPDATE daily_story
            SET video_path = ?
            WHERE date = ? AND age_group = ?
        ''', (video_path, date, age_group))
    elif age_group == "9-11":
        cursor.execute('''
            UPDATE daily_story
            SET video_path = ?
            WHERE date = ? AND age_group = ?
        ''', (video_path, date, age_group))
    
    conn.commit()
    conn.close()


def check_if_video_exists(date, age_group):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT video_path,story
        FROM daily_story
        WHERE date = ? AND age_group = ?
    ''', (date, age_group))
    
    result = cursor.fetchone()
    conn.close()
    
    if result and result[0]:
        return result[0]  # Return existing video path
    return None












@app.get("/kids/v2/generate-story/")
async def generate_story_endpoint(request: Request):
    today = datetime.today().strftime('%Y-%m-%d')

    # Default story and video path
    default_story = (
        "Once upon a time in the Whispering Woods, there was a kind little rabbit named Rosie. "
        "Rosie loved to help her friends, especially the slow-moving turtle, Timmy. Unlike the other animals, "
        "Rosie never teased Timmy for being slow.\n\nOne sunny day, a fierce fox named Freddie challenged Timmy to a race. "
        "All the animals giggled, sure that Timmy would lose. But Rosie whispered to Timmy, 'Believe in yourself, and I'll be there to cheer you on.'\n\n"
        "On the day of the race, Freddie dashed ahead, but quickly grew tired. Timmy, moving steadily and surely, didn’t stop, motivated by Rosie’s cheers. "
        "Freddie, overconfident, took a nap. Timmy slowly but surely crossed the finish line first, astonishing all the onlookers.\n\n"
        "Rosie hugged Timmy and said, 'Being kind and believing in yourself can lead to wonderful surprises.' "
        "From then on, the Whispering Woods animals learned to appreciate everyone's unique strengths and always be kind.\n\nThe End."
    )
    default_video_path = "generated_content/7-8/default_video.mp4"

    try:
        age_param = request.query_params.get('age')
        if not age_param:
            raise HTTPException(status_code=400, detail="Missing 'age' parameter")

        try:
            age = int(age_param)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid 'age' parameter. Age must be an integer.")
        
        if 5 <= age <= 6:
            age_group = "5-6"
        elif 7 <= age <= 8:
            age_group = "7-8"
        elif 9 <= age <= 11:
            age_group = "9-11"
        else:
            raise HTTPException(status_code=400, detail="Invalid age group")
        
        
        story, image_url = load_story_from_database(today, age_group)
        username_param1 = request.query_params.get('username')
        score_param1 = request.query_params.get('score')

        if score_param1 is not None:
            try:
                score_param1 = int(score_param1)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid score. Score must be an integer.")

        if username_param1 and score_param1 is not None:
            if not check_if_user_submitted_score1(today, username_param1):
                save_story_score_to_database(today, username_param1, score_param1)
        total_score = get_total_score(username_param1)
        existing_video_path = check_if_video_exists(today, age_group)
        if existing_video_path:
            # Update the streak table
            update_streak_for_story(today, username_param1)
            delete_previous_day_video(age_group)
            return {
                "story": story,
                "image": None,
                "video_path": existing_video_path,
                "username": username_param1,
                "score": score_param1,
                "total_score": None
            }

        # if not story:
        #     topic = get_daily_topic2()
        #     while True:
        #         story = generate_story(age, topic)
        #         image_url = generate_url(story)
        #         if not check_if_story_exists(today, age_group):
        #             break
        #     save_story_to_database(today, age_group, story, image_url)

        # video_path = generate_video_from_story(story, age_group)
        # update_video_path_in_database(today, age_group, video_path)
        
        # total_score = None
        # if username_param1 and score_param1 is not None:
        #     if not check_if_user_submitted_score1(today, username_param1):
        #         save_story_score_to_database(today, username_param1, score_param1)
        #     total_score = get_total_score(username_param1)

        # # Update the streak table
        # update_streak_for_story(today, username_param1)
        # delete_previous_day_video(age_group)

        # return {
        #     "story": story,
        #     "image": image_url,
        #     "video_path": video_path,
        #     "username": username_param1,
        #     "score": score_param1,
        #     "total_score": total_score
        # }
    
    except Exception as e:
        # Return the default story and video path if any error occurs
        return {
            "story": default_story,
            "image": None,
            "video_path": default_video_path,
            "username": None,
            "score": None,
            "total_score": None,
            "error": str(e)
        }












def update_streak_for_story(date: str, username: str):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()

    # Check if the user has an entry for today
    cursor.execute('''
        SELECT id FROM streak WHERE date = ? AND username = ?
    ''', (date, username))
    result = cursor.fetchone()

    if result:
        # Update the streak table with story = 1 for the existing entry
        cursor.execute('''
            UPDATE streak
            SET story = 1
            WHERE date = ? AND username = ?
        ''', (date, username))
    else:
        # Insert a new entry with story = 1
        cursor.execute('''
            INSERT INTO streak (username, story, date)
            VALUES (?, 1, ?)
        ''', (username, date))

    conn.commit()
    conn.close()









@app.get("/kids/v2/get-video/")
async def get_video(video_path: str):
    if os.path.exists(video_path):
        return FileResponse(video_path, media_type="video/mp4")
    else:
        raise HTTPException(status_code=404, detail="Video not found")





# Function to connect to the SQLite database
def connect_db():
    return sqlite3.connect("kids_chat.db")

# API endpoint to get credits data by username
@app.get("/kids/v2/credits/{username}")
async def get_credits(username: str):
    # Connect to the database
    conn = connect_db()
    cursor = conn.cursor()

    # SQL query to retrieve credits data by username
    query = "SELECT * FROM users WHERE username = ?"
    cursor.execute(query, (username,))
    result = cursor.fetchone()  # Use fetchone to get a single record

    # Check if user exists
    if result is None:
        raise HTTPException(status_code=404, detail="User not found")

    user_data = {
        "id": result[0],
        "username": result[1],
        "credits": result[2],
        'name': result[4], 
        'age': result[5], 
        'gender': result[6],     
        'dreamCareer': result[7],
        'avatar':result[8],
        'dob':result[3],
        'story':result[9],
        'question':result[10],
        'quiz':result[11],
        'joke':result[12],
        'game':result[13],
        'remainder':result[14],
        'profile':result[15],
        'parrentPassword':result[16],
        'avatar_path':result[17],
        'appliedTheme':result[18],
        'time':result[19],
    }
    conn.close()
    return user_data


import sqlite3

def create_all_credits_db():
    # Create new database and table
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()

    # Create the all_credits table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS all_credits (
        username TEXT PRIMARY KEY,
        chat_credits INTEGER DEFAULT 0,
        quiz_credits INTEGER DEFAULT 0,
        question_credits INTEGER DEFAULT 0,
        story_credits INTEGER DEFAULT 0,
        total_credits INTEGER DEFAULT 0
    )
    ''')
    conn.commit()
    conn.close()

def fetch_data_and_update_all_credits():
    # Connect to the new database
    conn_all_credits = sqlite3.connect('kids_chat.db')
    cursor_all_credits = conn_all_credits.cursor()

    # Helper function to fetch data from other databases
    def fetch_and_update(db_name, query, column_name):
        try:
            conn = sqlite3.connect(db_name)
            cursor = conn.cursor()
            cursor.execute(query)
            data = cursor.fetchall()
            for username, score in data:
                cursor_all_credits.execute(f'''
                    INSERT INTO all_credits (username, {column_name}, total_credits)
                    VALUES (?, ?, ?)
                    ON CONFLICT(username) DO UPDATE SET
                    {column_name} = excluded.{column_name},
                    total_credits = total_credits + excluded.{column_name}
                ''', (username, score, score))
            conn.close()
        except sqlite3.OperationalError as e:
            print(f"Error with database {db_name}: {e}")

    # Fetch chat credits
    fetch_and_update('kids_chat.db', 'SELECT username, credits FROM credits', 'chat_credits')

    # Fetch quiz credits
    fetch_and_update('kids_chat.db', 'SELECT username, score FROM quiz_submissions1', 'quiz_credits')

    # Fetch question credits
    fetch_and_update('kids_chat.db', 'SELECT username, score FROM question_score1', 'question_credits')

    # Fetch story credits (make sure the table and columns exist)
    fetch_and_update('kids_chat.db', 'SELECT username, score FROM story_score1', 'story_credits')

    conn_all_credits.commit()
    conn_all_credits.close()


create_all_credits_db()
fetch_data_and_update_all_credits()


def get_daily_topic3():
    tomorrow = datetime.now() + timedelta(days=1)
    topic_index = tomorrow.day % 30
    topics = ['friends', 'basic awareness', 'logical', "animals", "movies", "parents", "low", "political", "police", 
              "engineers","Dinosaurs", "Aliens", "Robots", "Pirates", "Monsters", "Pizza", "Unicorns",
            "schools", "Dragons", "Penguins", "Jellybeans", "Fairies", "Spaceships",
            "Ghosts", "Knights", "Spaghetti", "Elephants", "Cupcakes", "Balloons", "Superheroes"]
    return topics[topic_index]

def generate_joke(topic):
    prompt = f"Generate a funny and appropriate joke on {topic} for small kids. Use very simple words."
    client = OpenAI(
            api_key='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'  #os.environ.get('OPENAI_API_KEY')
        )
    response = client.chat.completions.create(
            messages=[
                {"role": "system", "content": prompt},
            ],
            max_tokens=500,
            temperature=1,
            model="gpt-4o"
        )
    joke = response.choices[0].message.content
    print(topic)
    return joke




def initialize_database():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    try:
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_joke (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,
                joke TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS joke_score (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,
                username TEXT,
                score INTEGER,
                UNIQUE(date, username)
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS joke_score1 (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                score INTEGER
            )
        ''')
        conn.commit()
    except sqlite3.Error as e:
        print(f"Error initializing database: {e}")
    finally:
        conn.close()

def save_joke_to_database(date, joke):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO daily_joke (date, joke) VALUES (?, ?)
    ''', (date, joke))
    conn.commit()
    conn.close()

def save_user_score_to_database(date, username, score):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO joke_score (date, username, score) VALUES (?, ?, ?)
        ''', (date, username, score))
        cursor.execute("INSERT INTO history (username, score, date,field) VALUES (?, ?, ?, ?)",
                (username, score, date,"joke"))
        conn.commit()
        update_cumulative_score(username, score)
    except sqlite3.IntegrityError:
        print(f"Score for username {username} on {date} already exists.")
    finally:
        conn.close()

def update_cumulative_score(username, score):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO joke_score1 (username, score)
        VALUES (?, ?)
        ON CONFLICT(username) DO UPDATE SET score = score + ?
    ''', (username, score, score))
    conn.commit()
    conn.close()

def load_joke_from_database(date):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT joke FROM daily_joke WHERE date = ?
    ''', (date,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return row[0]
    else:
        return None

def check_if_joke_exists(joke):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT COUNT(*) FROM daily_joke WHERE joke = ?
    ''', (joke,))
    count = cursor.fetchone()[0]
    conn.close()
    return count > 0

def check_if_user_submitted_score(date, username):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT COUNT(*) FROM joke_score WHERE date = ? AND username = ?
    ''', (date, username))
    count = cursor.fetchone()[0]
    conn.close()
    return count > 0

@app.get("/kids/v2/generate-joke/")
async def generate_joke_endpoint(request: Request):
    initialize_database()
    today = datetime.today().strftime('%Y-%m-%d')
    joke = load_joke_from_database(today)

    # Get username and score from query parameters
    username_param = request.query_params.get('username')
    score_param = request.query_params.get('score')

    # Ensure score is converted to an integer if it exists
    if score_param is not None:
        try:
            score_param = int(score_param)
        except ValueError:
            return {"error": "Invalid score. Score must be an integer."}

    if not joke:
        topic = get_daily_topic3()
        print("joke topic", topic)
        while True:
            joke = generate_joke(topic)
            if not check_if_joke_exists(joke):
                break

        save_joke_to_database(today, joke)

    if username_param and score_param is not None:
        if not check_if_user_submitted_score(today, username_param):
            save_user_score_to_database(today, username_param, score_param)

    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM streak WHERE username = ? AND date = ?", (username_param, today))
    streak_record = cursor.fetchone()

    if streak_record:
        cursor.execute("UPDATE streak SET joke = 1 WHERE username = ? AND date = ?", (username_param, today))
    else:
        cursor.execute("INSERT INTO streak (username, joke, date) VALUES (?, ?, ?)", (username_param, 1, today))

    conn.commit()
    conn.close()

    return {"joke": joke, "username": username_param, "score": score_param}




conn = sqlite3.connect('kids_chat.db')
cursor = conn.cursor()

# Create table
cursor.execute('''
CREATE TABLE IF NOT EXISTS remaind (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    date TEXT,
    time TEXT,
    username TEXT,
    frequency TEXT,
    daysofWeek TEXT                      
)
''')

conn.commit()
conn.close()





class Post(BaseModel):
    title: str
    description: str
    date: str
    time: str
    username: str
    frequency: str
    daysofWeek: List[str] = [] 

import json

def insert_post(title: str, description: str, date: str, time: str, username: str, frequency: str, daysofWeek: List[str] = []):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO remaind (title, description, date, time, username, frequency, daysofWeek)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (title, description, date, time, username, frequency, json.dumps(daysofWeek)))  # Convert list to JSON string
    conn.commit()
    conn.close()


@app.post("/kids/v2/add-reminder/")
async def add_post(post: Post):
    try:
        print("Received post data:", post)
        insert_post(post.title, post.description, post.date, post.time, post.username, post.frequency, post.daysofWeek)
        return {"message": "added successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    
    
@app.get("/kids/v2/get-reminders/")
async def get_reminders(username: str):
    print(username)
    try:
        conn = sqlite3.connect('kids_chat.db')
        cursor = conn.cursor()
        cursor.execute('''
        SELECT id, title, description, date, time, frequency, daysofWeek FROM remaind WHERE username = ?
        ''', (username,))
        reminders = cursor.fetchall()
        conn.close()
        if not reminders:
            raise HTTPException(status_code=404, detail="No reminders found for the given username")
        return [{
            "id": id,
            "title": title,
            "description": description,
            "date": date,
            "time": time,
            "frequency": frequency,
            "daysofWeek": json.loads(daysofWeek) if daysofWeek else []  # Ensure it's always an array
        } for id, title, description, date, time, frequency, daysofWeek in reminders]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))





@app.delete("/kids/v2/delete-reminder/{reminder_id}")
async def delete_reminder(reminder_id: int):
    try:
        conn = sqlite3.connect('kids_chat.db')
        cursor = conn.cursor()
        cursor.execute('''
        DELETE FROM remaind WHERE id = ?
        ''', (reminder_id,))
        conn.commit()
        conn.close()
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="No reminder found with the given ID")
        return {"detail": "Reminder deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    


    

def update_reminder(reminder_id: int, title: str, description: str, date: str, time: str, username: str, frequency: str, daysofWeek: List[str] = []):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
    UPDATE remaind
    SET title = ?, description = ?, date = ?, time = ?, username = ?, frequency = ?, daysofWeek = ?
    WHERE id = ?
    ''', (title, description, date, time, username, frequency, json.dumps(daysofWeek), reminder_id))  # Convert list to JSON string
    conn.commit()
    conn.close()




@app.put("/kids/v2/update-reminder/{reminder_id}")
async def update_reminder_endpoint(reminder_id: int, post: Post):
    try:
        update_reminder(reminder_id, post.title, post.description, post.date, post.time, post.username, post.frequency, post.daysofWeek)
        return {"message": "Reminder updated successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))












class PasswordRequest(BaseModel):
    username: str
    password: str

def get_db_connection():
    conn = sqlite3.connect('kids_chat.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.post("/kids/v2/validate_password/")
def validate_password(request: PasswordRequest):
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE username = ?', (request.username,)).fetchone()
    conn.close()
    if user is None or user['parrentPassword'] != request.password:
        raise HTTPException(status_code=400, detail="Invalid username or password")
    return {"message": "Password is valid"}



def get_db_connection():
    conn = sqlite3.connect("kids_chat.db")
    conn.row_factory = sqlite3.Row
    return conn


@app.put("/kids/v2/update-password/")
async def update_password(request: Request):
    data = await request.json()
    username = data.get('username')
    current_password = data.get('current_password')
    new_password = data.get('new_password')

    if not username:
        raise HTTPException(status_code=400, detail="Username is required")
    if not current_password:
        raise HTTPException(status_code=400, detail="Current password is required")
    if not new_password:
        raise HTTPException(status_code=400, detail="New password is required")

    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        stored_password = user['password']
        parent_password = user['parrentPassword']

        if stored_password != current_password:
            raise HTTPException(status_code=400, detail="Current password is incorrect")

        if new_password == parent_password:
            raise HTTPException(status_code=400, detail="New password cannot be the same as the parent password")

        cursor.execute("UPDATE users SET password = ? WHERE username = ?", (new_password, username))
        conn.commit()

    except sqlite3.Error as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

    return {"message": "Password updated successfully"}




DATABASES = {
    'credits': ('kids_chat.db', 'credits', 'credits'),
    'quiz': ('kids_chat.db', 'quiz_submissions1', 'score'),
    'daily_questions': ('kids_chat.db', 'question_score1', 'score'),
    'story': ('kids_chat.db', 'story_score1', 'score'),
    'joke': ('kids_chat.db', 'joke_score1', 'score')
}

@app.get("/kids/v2/get_scores/")
async def get_scores(request: Request):
    username = request.query_params.get('username')
    if not username:
        raise HTTPException(status_code=400, detail="Username is required")
    
    scores = {}
    for key, (db_path, table, column) in DATABASES.items():
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute(f"SELECT {column} FROM {table} WHERE username = ?", (username,))
            result = cursor.fetchone()
            conn.close()
            
            if result:
                scores[key] = result[0]
            else:
                scores[key] = None
        
        except sqlite3.Error as e:
            scores[key] = f"Error: {str(e)}"
    
    return scores



DATABASE = "kids_chat.db"

# Create a new SQLite database connection
def get_db_connection1():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# Model for the request body
class CreditUpdate(BaseModel):
    amount: int


@app.put("/kids/v2/update_credits/")
async def update_credits(request: Request, credit_update: CreditUpdate):
    username = request.query_params.get('username')

    amount = credit_update.amount
    conn = get_db_connection1()
    cursor = conn.cursor()

    cursor.execute("SELECT credits FROM credits WHERE username = ?", (username,))
    row = cursor.fetchone()
    
    if row is None:
        raise HTTPException(status_code=404, detail="User not found")

    new_credits = row['credits'] + amount

    cursor.execute("UPDATE credits SET credits = ? WHERE username = ?", (new_credits, username))
    if cursor.rowcount == 0:
        return {"message": "No points were added or deducted"}

    conn.commit()
    conn.close()

    if amount > 0:
        return {"message": "point added"}
    else:
        return {"message": "point deducted"}
    



DATABASE = 'kids_chat.db'

from sqlite3 import Connection


def get_db_connection() -> Connection:
    conn = sqlite3.connect(DATABASE)
    return conn

def init_db():
    conn = get_db_connection()
    with conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS levels (
                id INTEGER PRIMARY KEY ,
                start INTEGER NOT NULL,
                end INTEGER NOT NULL
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                age INTEGER
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS history (
                username TEXT,
                score INTEGER,
                FOREIGN KEY(username) REFERENCES users(username)
            )
        ''')

init_db()


class User(BaseModel):
    username: str

def get_user_age(username: str):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT age FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return row[0]
    return None

def get_user_total_score2(username: str):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(score) as total_score FROM history WHERE username = ?", (username,))
    total_score = cursor.fetchone()[0]
    if total_score is None:
        total_score = 0
    conn.close()
    return total_score




class Ranges(BaseModel):
    range1_start: int
    range1_end: int
    range2_start: int
    range2_end: int
    range3_start: int
    range3_end: int



def determine_user_level(total_score: int, age: int):
    user_level = "Unknown"
    
    if age in range(5, 7):  # Age group 5-6
        levels = [
            (0, 100, "Tiny Learner"),
            (101, 200, "Little Explorer"),
            (201, 300, "Junior Adventurer"),
            (301, 400, "Brave Discoverer"),
            (401, 500, "Star Hero"),
            (501, 600, "Super Voyager"),
            (601, 700, "Mighty Champion"),
            (701, 800, "Galactic Guardian"),
            (801, 900, "Ultimate Hero"),
            (901, 100000, "Legendary Explorer")
        ]
    elif age in range(7, 9):  # Age group 7-8
        levels = [
            (0, 100, "Curious Kid"),
            (101, 200, "Smart Explorer"),
            (201, 300, "Knowledge Seeker"),
            (301, 400, "Wisdom Collector"),
            (401, 500, "Learning Leader"),
            (501, 600, "Brain Builder"),
            (601, 700, "Master Explorer"),
            (701, 800, "Knowledge Knight"),
            (801, 900, "Learning Champion"),
            (901, 100000, "Genius Hero")
        ]
    elif age in range(9, 12):  # Age group 9-10
        levels = [
            (0, 100, "Bright Beginner"),
            (101, 200, "Quick Thinker"),
            (201, 300, "Brainy Scholar"),
            (301, 400, "Knowledge Hunter"),
            (401, 500, "Wisdom Seeker"),
            (501, 600, "Learning Wizard"),
            (601, 700, "Mastermind"),
            (701, 800, "Sage Explorer"),
            (801, 900, "Wisdom Guru"),
            (901, 100000, "Knowledge King")
        ]
    
    for start, end, title in levels:
        if start <= total_score <= end:
            user_level = title
            break

    return user_level



@app.post("/kids/v2/get-age/")
async def get_age(user: User):
    age = get_user_age(user.username)
    if age is not None:
        total_score = get_user_total_score2(user.username)
        print(total_score)
        user_level = determine_user_level(total_score, age)
        return {"age": age, "user_level": user_level}
    else:
        raise HTTPException(status_code=404, detail="User not found")











@app.get("/kids/v2/point_history/")
async def get_history(request: Request):
    username = request.query_params.get('username')
    
    if not username:
        return {"error": "Username is required"}
    
    connection = sqlite3.connect('kids_chat.db')
    cursor = connection.cursor()
    
    cursor.execute("SELECT username, date, score, field FROM history WHERE username = ?", (username,))
    rows = cursor.fetchall()
    
    connection.close()
    
    history = [{"username": row[0], "date": row[1], "score": row[2], "field": row[3]} for row in rows]
    
    return {"history": history}



def create_reddem_history_table():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS redeem_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            date TEXT NOT NULL,
            trends TEXT NOT NULL,
            purchase_amount INT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

create_reddem_history_table()

class RedeemHistory(BaseModel):
    username: str
    date: str
    trends: str
    purchase_amount: int









def get_db_connection():
    conn = sqlite3.connect('kids_chat.db', check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

# Function to get the user total score
def get_user_total_score(username, conn):
    with closing(conn.cursor()) as cursor:
        cursor.execute("SELECT credits FROM credits WHERE username = ?", (username,))
        user_credits = cursor.fetchone()
        user_credits = user_credits[0] if user_credits else 0

        cursor.execute("SELECT SUM(score) FROM quiz_submissions1 WHERE username = ?", (username,))
        quiz_score = cursor.fetchone()[0]
        quiz_score = quiz_score if quiz_score else 0

        cursor.execute("SELECT SUM(score) FROM question_score1 WHERE username = ?", (username,))
        daily_score = cursor.fetchone()[0]
        daily_score = daily_score if daily_score else 0

        cursor.execute("SELECT SUM(score) FROM story_score1 WHERE username = ?", (username,))
        story_score = cursor.fetchone()[0]
        story_score = story_score if story_score else 0

        cursor.execute("SELECT SUM(score) FROM joke_score1 WHERE username = ?", (username,))
        joke_score = cursor.fetchone()[0]
        joke_score = joke_score if joke_score else 0

        total_score = user_credits + quiz_score + daily_score + story_score + joke_score
        return total_score, user_credits, quiz_score, daily_score, story_score, joke_score

class RedeemHistory(BaseModel):
    username: str
    date: str
    trends: str
    purchase_amount: int

@app.get("/kids/v2/purchase/")
async def purchase(request: Request, conn: sqlite3.Connection = Depends(get_db_connection)):
    username = request.query_params.get('username')
    purchase_amount = request.query_params.get('purchase_amount')
    trends = request.query_params.get('trends')

    if not username or not purchase_amount or not trends:
        raise HTTPException(status_code=400, detail="Username, purchase amount, and trends are required")

    try:
        purchase_amount = int(purchase_amount)
    except ValueError:
        raise HTTPException(status_code=400, detail="Purchase amount must be a valid integer")

    with closing(conn.cursor()) as cursor:       
        try:
            total_score, user_credits, quiz_score, daily_score, story_score, joke_score = get_user_total_score(username, conn)

            if purchase_amount > total_score:
                raise HTTPException(status_code=400, detail="Insufficient score to complete the purchase")

            remaining_amount = purchase_amount

            if user_credits >= remaining_amount:
                cursor.execute("UPDATE credits SET credits = credits - ? WHERE username = ?", (remaining_amount, username))
                remaining_amount = 0
            else:
                remaining_amount -= user_credits
                cursor.execute("UPDATE credits SET credits = 0 WHERE username = ?", (username,))

            if remaining_amount > 0 and quiz_score > 0:
                if quiz_score >= remaining_amount:
                    cursor.execute("UPDATE quiz_submissions1 SET score = score - ? WHERE username = ?", (remaining_amount, username))
                    remaining_amount = 0
                else:
                    cursor.execute("UPDATE quiz_submissions1 SET score = 0 WHERE username = ?", (username,))
                    remaining_amount -= quiz_score

            if remaining_amount > 0 and daily_score > 0:
                if daily_score >= remaining_amount:
                    cursor.execute("UPDATE question_score1 SET score = score - ? WHERE username = ?", (remaining_amount, username))
                    remaining_amount = 0
                else:
                    cursor.execute("UPDATE question_score1 SET score = 0 WHERE username = ?", (username,))
                    remaining_amount -= daily_score

            if remaining_amount > 0 and story_score > 0:
                if story_score >= remaining_amount:
                    cursor.execute("UPDATE story_score1 SET score = score - ? WHERE username = ?", (remaining_amount, username))
                    remaining_amount = 0
                else:
                    cursor.execute("UPDATE story_score1 SET score = 0 WHERE username = ?", (username,))
                    remaining_amount -= story_score

            if remaining_amount > 0 and joke_score > 0:
                if joke_score >= remaining_amount:
                    cursor.execute("UPDATE joke_score1 SET score = score - ? WHERE username = ?", (remaining_amount, username))
                    remaining_amount = 0
                else:
                    cursor.execute("UPDATE joke_score1 SET score = 0 WHERE username = ?", (username,))
                    remaining_amount -= joke_score

            if remaining_amount > 0:
                raise HTTPException(status_code=400, detail="Not enough score to complete the purchase even after adjustments")

            cursor.execute('''
                SELECT 1 FROM redeem_history WHERE username = ? AND trends = ?
            ''', (username, trends))
            if cursor.fetchone():
                raise HTTPException(status_code=400, detail="User has already redeemed this trend")

            today_date = datetime.today().strftime('%Y-%m-%d')
            redeem_history = RedeemHistory(username=username, date=today_date, trends=trends, purchase_amount=purchase_amount)

            cursor.execute('''
                INSERT INTO redeem_history (username, date, trends, purchase_amount)
                VALUES (?, ?, ?, ?)
            ''', (redeem_history.username, redeem_history.date, redeem_history.trends, redeem_history.purchase_amount))

            conn.commit()

        except Exception as e:
            conn.rollback()
            raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

    return {"message": "Purchase and redeem history added successfully"}



@app.get("/kids/v2/purchase_history/")
async def get_history(request: Request):
    username = request.query_params.get('username')
    
    if not username:
        return {"error": "Username is required"}
    
    connection = sqlite3.connect('kids_chat.db')
    cursor = connection.cursor()
    
    cursor.execute("SELECT username, date, trends, purchase_amount FROM redeem_history WHERE username = ?", (username,))
    rows = cursor.fetchall()
    
    connection.close()
    
    history = [{"username": row[0], "date": row[1], "trends": row[2], "purchase_amount": row[3]} for row in rows]
    
    return {"history": history}





def create_games_table():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS games (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT,
                        game_name TEXT,
                        score INTEGER,
                        time INTEGER
                    )''')
    conn.commit()
    conn.close()

# Initialize the games table
create_games_table()

def insert_or_update_game_score(username, game_name, score=None, time=None):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    
    # Fetch the existing record if it exists
    cursor.execute('''SELECT score, time FROM games WHERE username = ? AND game_name = ?''', (username, game_name))
    record = cursor.fetchone()
    
    if game_name == "Spelling Bee":
        if record:
            # If a record exists, update if the new score is greater
            if score > record[0]:
                cursor.execute('''UPDATE games SET score = ? WHERE username = ? AND game_name = ?''', (score, username, game_name))
        else:
            # Insert a new record if none exists
            cursor.execute('''INSERT INTO games (username, game_name, score) VALUES (?, ?, ?)''', (username, game_name, score))
    elif game_name == "Memory Match":
        if record:
            # If a record exists, update if the new time is less
            if time < record[1]:
                cursor.execute('''UPDATE games SET time = ? WHERE username = ? AND game_name = ?''', (time, username, game_name))
        else:
            # Insert a new record if none exists
            cursor.execute('''INSERT INTO games (username, game_name, time) VALUES (?, ?, ?)''', (username, game_name, time))

    conn.commit()
    conn.close()
used_words = {"Easy": set(), "Medium": set(), "Difficult": set()}
logger = logging.getLogger("Flowai3")
logger.setLevel(logging.INFO)
class SpellingBeeResult(BaseModel):
    username: str
    score: int

@app.get("/kids/v2/spellingbee/words")
async def get_spellingbee_words(level: str):
    prompts = {
        "Easy": "Give me a single easy word suitable for a 5-6 year old.",
        "Medium": "Give me a single medium word suitable for a 7-8 year old.",
        "Difficult": "Give me a single difficult word suitable for a 9-10 year old."
    }
    
    if level not in prompts:
        logger.error(f"Invalid level: {level}")
        raise HTTPException(status_code=400, detail="Invalid level")

    try:
        logger.info(f"Fetching word for level: {level}")
        client = openai.OpenAI(api_key='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')
        used_words_prompt = ", ".join(used_words[level])
        prompt = f"{prompts[level]} Exclude these words: {used_words_prompt}."
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a teacher."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=10,
            temperature=0
        )
        word = response.choices[0].message.content.strip().split()[0]
        
        if word in used_words[level]:
            raise Exception("Generated word is already used. Try again.")

        used_words[level].add(word)
        logger.info(f"Fetched word: {word}")
        return {"word": word}
    except openai.OpenAIError as e:
        logger.error(f"OpenAI API error: {e}")
        raise HTTPException(status_code=500, detail=f"OpenAI API error: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")
@app.get("/kids/v2/spellingbee/hints")
async def get_spellingbee_hints(word: str):
    if not word:
        logger.error("Word is required")
        raise HTTPException(status_code=400, detail="Word is required")
    
    try:
        logger.info(f"Fetching hints for word: {word}")
        client = openai.OpenAI(api_key='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')
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a teacher."},
                {"role": "user", "content": f"Provide pronunciation, definition, and a sentence for the word '{word}'."}
            ],
            max_tokens=150,
            temperature=0
        )
        logger.info(f"OpenAI response: {response}")
        message_content = response.choices[0].message.content.strip()
        hints = message_content.split('\n')
        if len(hints) < 3:
            logger.error(f"Insufficient hints data for word: {word}")
            raise HTTPException(status_code=500, detail="Insufficient hints data")

        return {
            "pronunciation": hints[0],
            "definition": hints[1],
            "sentence": hints[2]
        }
    except openai.OpenAIError as e:
        logger.error(f"OpenAI API error: {e}")
        raise HTTPException(status_code=500, detail=f"OpenAI API error: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

@app.post("/kids/v2/spellingbee/submit")
async def submit_spellingbee(result: SpellingBeeResult):
    try:
        insert_or_update_game_score(result.username, "Spelling Bee", score=result.score)
        logger.info(f"Quiz result submitted for user: {result.username}")
        return {"message": "Quiz result submitted successfully"}
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred")
    
    
class AvatarRequest(BaseModel):
    style: str
    skin_color: str
    top_type: str
    hair_color: str
    hat_color: str
    facial_hair_type: str
    facial_hair_color: str
    mouth_type: str
    eye_type: str
    eyebrow_type: str
    accessories_type: str
    clothe_type: str
    clothe_color: str
    clothe_graphic_type: str

DATABASE = 'kids_chat.db'
db_path = 'kids_chat.db'

def update_avatar_dir(username: str, avatar_file_path: str):
    """Update the AvatarDir column in the users table."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET AvatarDir = ? WHERE username = ?", (avatar_file_path, username))
    conn.commit()
    conn.close()


@app.post("/kids/v2/generate-avatar/")
async def generate_avatar(request: Request, avatar_request: AvatarRequest):
    try:
        username = request.query_params.get("username")
        logging.info(f"Received request for username: {username}")
        
        if not username:
            raise HTTPException(status_code=400, detail="Username is required")

        # Create a special path for the username
        user_dir = Path("media") / username
        user_dir.mkdir(parents=True, exist_ok=True)

        # Validate and map attributes
        def get_attr(attr, value):
            try:
                return getattr(attr, value)
            except AttributeError:
                logging.error(f"Invalid attribute value: {value} for {attr}")
                raise HTTPException(status_code=400, detail=f"Invalid attribute value: {value} for {attr}")

        avatar = pa.PyAvataaar(
            style=get_attr(pa.AvatarStyle, avatar_request.style),
            skin_color=get_attr(pa.SkinColor, avatar_request.skin_color),
            top_type=get_attr(pa.TopType, avatar_request.top_type),
            hair_color=get_attr(pa.HairColor, avatar_request.hair_color),
            # hat_color=get_attr(pa.ClotheColor, avatar_request.hat_color),  # Correct attribute check
            facial_hair_type=get_attr(pa.FacialHairType, avatar_request.facial_hair_type),
            facial_hair_color=get_attr(pa.HairColor, avatar_request.facial_hair_color),  # Corrected attribute
            mouth_type=get_attr(pa.MouthType, avatar_request.mouth_type),
            eye_type=get_attr(pa.EyesType, avatar_request.eye_type),
            eyebrow_type=get_attr(pa.EyebrowType, avatar_request.eyebrow_type),
            nose_type=pa.NoseType.DEFAULT,
            accessories_type=get_attr(pa.AccessoriesType, avatar_request.accessories_type),
            clothe_type=get_attr(pa.ClotheType, avatar_request.clothe_type),
            # clothe_color=get_attr(pa.ClotheColor, avatar_request.clothe_color),  # Corrected attribute
            clothe_graphic_type=get_attr(pa.ClotheGraphicType, avatar_request.clothe_graphic_type)
        )

        # Generate avatar PNG image
        with io.BytesIO() as image_io:
            avatar.render_png_file(image_io)
            image_bytes = image_io.getvalue()
            b64_image = base64.b64encode(image_bytes).decode('utf-8')

        # Save image to a file in the user's directory
        filename = f"avatar_{datetime.now().strftime('%Y%m%d%H%M%S')}.png"
        file_path = user_dir / filename
        with open(file_path, "wb") as f:
            f.write(image_bytes)

        # Save the file path in the database
        # update_avatar_dir(username, str(file_path))

        # Return the media URL and file path
        avatar_url = f"/media/{username}/{filename}"
        
        logging.info(f"Avatar generated successfully for username: {username}")

        return {"avatar_url": avatar_url, "avatar_image": b64_image, "file_path": str(file_path)}
    except AttributeError as ae:
        logging.error(f"Attribute error: {str(ae)}")
        raise HTTPException(status_code=400, detail=f"Attribute error: {str(ae)}")
    except Exception as e:
        logging.error(f"Error generating avatar for username {username}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    
def get_image(username: str, filename: str, image_directory: str):
    file_path = os.path.join(image_directory, username, filename)
    logging.info(f"Checking file path: {file_path}")
    if os.path.exists(file_path):
        logging.info(f"File found: {file_path}")
        return FileResponse(file_path)
    logging.error(f"File not found: {file_path}")
    raise HTTPException(status_code=404, detail=f"File not found: {file_path}")

def get_filenames_from_avatar_dir(db_path: str, username: str):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        cursor.execute('SELECT AvatarDir FROM users WHERE username = ?', (username,))
        paths = cursor.fetchall()
        print(paths)
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        filenames = [os.path.basename(path[0]) for path in paths if path[0] is not None]
        #filenames = [path[0] for path in paths if path[0] is not None]
        print(f"Retrieved filenames: {filenames}")  # Log filenames
        return filenames
    finally:
        conn.close()
        
        
        
logging.basicConfig(level=logging.INFO)


@app.post("/kids/v2/save-avatar/")
async def save_avatar(request: Request):
    try:
        
        data = await request.json()
        username = data.get("username")
        avatar_path = data.get("avatar_path")
        

        if not username or not avatar_path:
            raise HTTPException(status_code=400, detail="Username and avatar path are required")

        update_avatar_dir(username, avatar_path)

        filenames = get_filenames_from_avatar_dir(db_path, username)
        
        print(f"Avatar path: {avatar_path}")
        print(f"Filenames from database: {filenames}")

        # Extract filename from avatar_path
        avatar_filename = os.path.basename(avatar_path)

        if avatar_filename not in filenames:
            raise HTTPException(status_code=404, detail=f"Avatar path not found in filenames: {avatar_path}")

        return avatar_path
    except Exception as e:
        logging.error(f"Error in save_avatar: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/kids/v2/get-image/")
async def get_image_endpoint(username: str, filenames: str):
    print(username, filenames)
    try:
        return get_image(username, filenames, "media")
    except HTTPException as e:
        logging.error(f"Error in get_image_endpoint: {str(e)}")
        raise e
    except Exception as e:
        logging.error(f"Unexpected error in get_image_endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal Server Error")    





def get_correct_answer2(question):


    client = OpenAI(
        api_key = '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' 
        )
    response = client.chat.completions.create(
        
   
    messages = [
        {"role": "system", "content": f"Question: {question}\nAnswer:"},
        
    ],
    max_tokens=100,  
    temperature=0,
    model="gpt-4"
        ) 
    return response.choices[0].message.content
        
asked_questions = set()



import random


def is_similar_to_previous2(new_question):
    if not asked_questions:
        return False
    vectorizer = TfidfVectorizer().fit(list(asked_questions))
    new_question_vec = vectorizer.transform([new_question])
    similarity_scores = cosine_similarity(new_question_vec, vectorizer.transform(list(asked_questions)))[0]
    return any(score > 0.7 for score in similarity_scores)

def is_valid_question2(question):
    return len(question.split()) > 3 




def get_correct_answer2(question):
    client = OpenAI(api_key='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')
    response = client.chat.completions.create(
        messages=[
            {"role": "system", "content": f" give the correct answer from option with indexing: {question}\nAnswer:"},
        ],
        max_tokens=100,
        temperature=0,
        model="gpt-4"
    )
    return response.choices[0].message.content

asked_questions = set()

def generate_questions2(question_answers):
    while True:
        prompt1 = '''generate a multiple-choice question on politeness-related question concepts setup in a cave suitable for young children, Ensure the question and options are age-appropriate, engaging, and easy to understand for young learners. All the options should not be enclosed in double quotes.
    Please use polite words such as sorry, please, thank you, excuse me, may I help you.
    Question Format must be question then options A), B), C), D)'''
        
        client = OpenAI(api_key='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')
        response = client.chat.completions.create(
            messages=[
                {"role": "system", "content": prompt1},
            ],
            max_tokens=150,
            temperature=1,
            model="gpt-4"
        )
        question = response.choices[0].message.content
        
        if is_valid_question2(question) and not is_similar_to_previous2(question):
            correct_answer = get_correct_answer2(question)
            asked_questions.add(question)
            question_answers[question] = correct_answer
            return question, correct_answer

def is_similar_to_previous2(new_question):
    if not asked_questions:
        return False
    vectorizer = TfidfVectorizer().fit(list(asked_questions))
    new_question_vec = vectorizer.transform([new_question])
    similarity_scores = cosine_similarity(new_question_vec, vectorizer.transform(list(asked_questions)))[0]
    return any(score > 0.7 for score in similarity_scores)

def is_valid_question2(question):
    return len(question.split()) > 3 

@app.post("/kids/v2/quiz2")
async def start_quiz2():
    global asked_questions
    asked_questions.clear()
    question_answers = {}
    questions = []
    try:
        while len(questions) < 1:  # Generate 10 unique questions
            question_text, correct_answer = generate_questions2(question_answers)
            questions.append({"text": question_text, "answer": correct_answer})
        random.shuffle(questions)  # Shuffle the questions to randomize their order
        return {"questions": questions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def is_similar_to_previous3(new_question):
    if not asked_questions:
        return False
    vectorizer = TfidfVectorizer().fit(list(asked_questions))
    new_question_vec = vectorizer.transform([new_question])
    similarity_scores = cosine_similarity(new_question_vec, vectorizer.transform(list(asked_questions)))[0]
    return any(score > 0.7 for score in similarity_scores)

def is_valid_question3(question):
    return len(question.split()) > 3 


def get_correct_answer3(question):
    client = OpenAI(api_key='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')
    response = client.chat.completions.create(
        messages=[
            {"role": "system", "content": f" give the correct answer from option with indexing: {question}\nAnswer:"},
        ],
        max_tokens=100,
        temperature=0,
        model="gpt-4"
    )
    return response.choices[0].message.content

asked_questions = set()

def generate_questions3(question_answers):
    while True:
        prompt1 = '''generate a multiple-choice question on curiosity question concepts setup in a cave suitable for young children, Ensure the question and options are age-appropriate, engaging, and easy to understand for young learners. All the options should not be enclosed in double quotes.
    Please use words such as what, why, when in the questions.
    Question Format must be question then options A), B), C), D)'''
        
        client = OpenAI(api_key='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')
        response = client.chat.completions.create(
            messages=[
                {"role": "system", "content": prompt1},
            ],
            max_tokens=150,
            temperature=1,
            model="gpt-4"
        )
        question = response.choices[0].message.content
        
        if is_valid_question3(question) and not is_similar_to_previous3(question):
            correct_answer = get_correct_answer3(question)
            asked_questions.add(question)
            question_answers[question] = correct_answer
            return question, correct_answer

def is_similar_to_previous2(new_question):
    if not asked_questions:
        return False
    vectorizer = TfidfVectorizer().fit(list(asked_questions))
    new_question_vec = vectorizer.transform([new_question])
    similarity_scores = cosine_similarity(new_question_vec, vectorizer.transform(list(asked_questions)))[0]
    return any(score > 0.7 for score in similarity_scores)

def is_valid_question3(question):
    return len(question.split()) > 3 

@app.post("/kids/v2/quiz3")
async def start_quiz3():
    global asked_questions
    asked_questions.clear()
    question_answers = {}
    questions = []
    try:
        while len(questions) < 1:  # Generate 10 unique questions
            question_text, correct_answer = generate_questions3(question_answers)
            questions.append({"text": question_text, "answer": correct_answer})
        random.shuffle(questions)  # Shuffle the questions to randomize their order
        return {"questions": questions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    





@app.post("/kids/v2/update_theme/")
async def update_theme(request: Request):
    username = request.query_params.get('username')
    theme_name = request.query_params.get('theme_name')
    
    if not username or not theme_name:
        raise HTTPException(status_code=400, detail="Username and theme_name are required")
    
    try:
        conn = sqlite3.connect('kids_chat.db')
        cursor = conn.cursor()

        # Update the appliedthemes field for the given username
        cursor.execute("UPDATE users SET appliedthemes = ? WHERE username = ?", (theme_name, username))
        
        conn.commit()
        conn.close()

        return {"success": "Theme updated successfully"}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

# class ProfileUpdate(BaseModel):
#     name: str
#     dob: str
#     dreamCareer: str
#     gender: str

# def update_profile(username: str, name: str, dob: str, dreamCareer: str, gender: str):
#     conn = sqlite3.connect('kids_chat.db')
#     cursor = conn.cursor()
#     cursor.execute('''UPDATE users
#                       SET name = ?,
#                           dob = ?,
#                           dreamCareer = ?,
#                           gender = ?
#                       WHERE username = ?''',
#                    (name, dob, dreamCareer, gender, username))
#     conn.commit()
#     conn.close()

# @app.put("/kids/v2/update-profile/")
# def update_user_profile(username: str, profile: ProfileUpdate):
#     try:
#         update_profile(username, profile.name, profile.dob, profile.dreamCareer, profile.gender)
#         return {"message": "Profile updated successfully"}
#     except Exception as e:
#         raise HTTPException(status_code=400, detail=str(e))




from fastapi import FastAPI, HTTPException, Query, Depends, Body
from pydantic import BaseModel, Field
from typing import Optional
import sqlite3
from contextlib import contextmanager



DATABASE = "kids_chat.db"  # Path to your SQLite database

# Pydantic model for optional update fields
# class UserUpdate(BaseModel):
#     name: Optional[str] = None
#     dob: Optional[str] = None  # Keep 'dob' as a string
#     dreamCareer: Optional[str] = None
#     gender: Optional[str] = None

# @contextmanager
# def get_db():
#     conn = sqlite3.connect(DATABASE)
#     try:
#         yield conn
#     finally:
#         conn.close()

# @app.put("/kids/v2/update-profile/")
# async def update_profile(
#     username: str = Query(...),
#     user_update: UserUpdate = Depends()
# ):
#     with get_db() as conn:
#         cursor = conn.cursor()

#         # Fetch existing user to check if user exists
#         cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
#         user = cursor.fetchone()
        
#         if user is None:
#             raise HTTPException(status_code=404, detail="User not found")

#         # Prepare the update statement
#         updates = []
#         params = []

#         if user_update.name is not None:
#             updates.append("name = ?")
#             params.append(user_update.name)
#         if user_update.dob is not None:
#             updates.append("dob = ?")
#             params.append(user_update.dob)
#         if user_update.dreamCareer is not None:
#             updates.append("dreamCareer = ?")
#             params.append(user_update.dreamCareer)
#         if user_update.gender is not None:
#             updates.append("gender = ?")
#             params.append(user_update.gender)
        
#         if not updates:
#             raise HTTPException(status_code=400, detail="No fields to update")

#         update_query = "UPDATE users SET " + ", ".join(updates) + " WHERE username = ?"
#         params.append(username)

#         # Execute the update
#         cursor.execute(update_query, tuple(params))
#         conn.commit()

#         return {"message": "Profile updated successfully"}


class UserUpdate(BaseModel):
    name: Optional[str] = None
    dob: Optional[str] = None  # Keep 'dob' as a string
    dreamCareer: Optional[str] = None
    gender: Optional[str] = None

@contextmanager
def get_db():
    conn = sqlite3.connect(DATABASE)
    try:
        yield conn
    finally:
        conn.close()

# @app.put("/kids/v2/update-profile/")
# async def update_profile(
#     username: str = Query(...),
#     user_update: UserUpdate = Body(...)
# ):
#     print(f"Received username: {username}")  # Debugging log
#     print(f"Received update: {user_update}")  # Debugging log

#     with get_db() as conn:
#         cursor = conn.cursor()

#         # Check if the user exists
#         cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
#         user = cursor.fetchone()
        
#         if user is None:
#             raise HTTPException(status_code=404, detail="User not found")

#         # Fetch current values
#         current_values = {
#             'name': user[1],  # Adjust index according to your table structure
#             'dob': user[2],   # Adjust index according to your table structure
#             'dreamCareer': user[3],  # Adjust index according to your table structure
#             'gender': user[4]  # Adjust index according to your table structure
#         }

#         updates = []
#         params = []

#         if user_update.name is not None:
#             updates.append("name = ?")
#             params.append(user_update.name)
#         else:
#             params.append(current_values['name'])
        
#         if user_update.dob is not None:
#             updates.append("dob = ?")
#             params.append(user_update.dob)
#         else:
#             params.append(current_values['dob'])
        
#         if user_update.dreamCareer is not None:
#             updates.append("dreamCareer = ?")
#             params.append(user_update.dreamCareer)
#         else:
#             params.append(current_values['dreamCareer'])
        
#         if user_update.gender is not None:
#             updates.append("gender = ?")
#             params.append(user_update.gender)
#         else:
#             params.append(current_values['gender'])

#         if not updates:
#             raise HTTPException(status_code=400, detail="No fields to update")

#         update_query = "UPDATE users SET " + ", ".join(updates) + " WHERE username = ?"
#         params.append(username)

#         cursor.execute(update_query, tuple(params))
#         conn.commit()

#         return {"message": "Profile updated successfully"}


 # Adjust according to your file structure

@app.put("/kids/v2/update-profile/")
async def update_profile(
    username: str = Query(...),
    user_update: UserUpdate = Body(...)
):
    print(f"Received username: {username}")  # Debugging log
    print(f"Received update: {user_update}")  # Debugging log

    with get_db() as conn:
        cursor = conn.cursor()

        # Check if the user exists
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")

        # Fetch current values
        current_values = {
            'name': user[1],  # Adjust index according to your table structure
            'dob': user[2],   # Adjust index according to your table structure
            'dreamCareer': user[3],  # Adjust index according to your table structure
            'gender': user[4]  # Adjust index according to your table structure
        }

        updates = []
        params = []

        # Prepare update parameters
        if user_update.name is not None and user_update.name.strip() != "":
            updates.append("name = ?")
            params.append(user_update.name)
        
        if user_update.dob is not None and user_update.dob.strip() != "":
            updates.append("dob = ?")
            params.append(user_update.dob)
        
        if user_update.dreamCareer is not None and user_update.dreamCareer.strip() != "":
            updates.append("dreamCareer = ?")
            params.append(user_update.dreamCareer)
        
        if user_update.gender is not None and user_update.gender.strip() != "":
            updates.append("gender = ?")
            params.append(user_update.gender)

        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")

        # Construct the update query
        update_query = "UPDATE users SET " + ", ".join(updates) + " WHERE username = ?"
        params.append(username)

        print(f"Update query: {update_query}")  # Debugging log
        print(f"Parameters: {params}")  # Debugging log

        cursor.execute(update_query, tuple(params))
        conn.commit()

        return {"message": "Profile updated successfully"}







import sqlite3

DATABASE = 'kids_chat.db'  # Ensure this is the correct path to your database

def create_user_points_table():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # Create the new table to store the sum of points for each username
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS user_points (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        total_points INTEGER DEFAULT 0
    )
    ''')
    conn.commit()
    conn.close()

# Call this function once to create the table
create_user_points_table()


def update_user_points(username: str):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # Calculate the sum of points for the given username
    cursor.execute('''
    SELECT SUM(point)
    FROM streak
    WHERE username = ?
    ''', (username,))
    total_points = cursor.fetchone()[0]
    


    if total_points is None:
        total_points = 0

    # Insert or update the total points for the username in the user_points table
    cursor.execute('''
    INSERT INTO user_points (username, total_points)
    VALUES (?, ?)
    ON CONFLICT(username) DO UPDATE SET total_points = excluded.total_points
    ''', (username, total_points))

    conn.commit()
    conn.close()


def get_streak_data(username: str, date: str):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    # Fetch streak data for the given username and date
    cursor.execute('''
    SELECT chat, quiz, question, joke, story, point
    FROM streak
    WHERE username = ? AND date = ?
    ''', (username, date))
    result = cursor.fetchone()

    if not result:
        conn.close()
        return None

    # Update the total column by summing chat, quiz, question, joke, and story
    cursor.execute('''
    UPDATE streak
    SET total = chat + quiz + question + story + joke
    WHERE username = ? AND date = ?
    ''', (username, date))
    conn.commit()

    # Fetch the updated total
    cursor.execute('SELECT total FROM streak WHERE username = ? AND date = ?', (username, date))
    total = cursor.fetchone()

    if total and total[0] == 5:
        # Increment the point column if total equals 5
        cursor.execute('''
            UPDATE streak
            SET point =  1
            WHERE username = ? AND date = ?
        ''', (username, date))
        conn.commit()

        # Re-fetch the streak data to get the updated points
        cursor.execute('''
        SELECT chat, quiz, question, joke, story, point
        FROM streak
        WHERE username = ? AND date = ?
        ''', (username, date))
        result = cursor.fetchone()

        # Update the user_points table with the new total points for the username
        

    conn.close()
    return result

@app.get("/kids/v2/milestone/")
async def read_streak(request: Request):
    username = request.query_params.get('username')
    date = request.query_params.get('date')
    

    if not username or not date:
        raise HTTPException(status_code=400, detail="Username and date are required")

    data = get_streak_data(username, date)
    update_user_points(username)
    delete_zero_point_streaks()
    if data:
        return {"chat": data[0], "quiz": data[1], "question": data[2], "joke": data[3], "story": data[4]}
    else:
        raise HTTPException(status_code=404, detail="Data not found for the given username and date")


def get_database_connection():
    conn = sqlite3.connect("kids_chat.db")
    return conn

@app.get("/kids/v2/get-total-points/")
async def get_total_points(request: Request):
    username = request.query_params.get('username')
    if not username:
        raise HTTPException(status_code=400, detail="Username is required")
    
    conn = get_database_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT total_points FROM user_points WHERE username = ?", (username,))
    result = cursor.fetchone()
    
    conn.close()
    
    if result is None:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"username": username, "total_points": result[0]}



def delete_zero_point_streaks(db_path='kids_chat.db'):
    # Connect to the database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Calculate yesterday's date
    yesterday = (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')

    # Select usernames with 0 points from yesterday
    cursor.execute("""
        SELECT username FROM streak 
        WHERE date = ? AND point = 0
    """, (yesterday,))
    users_to_delete = cursor.fetchall()

    # If there are users to delete, proceed with the deletion
    if users_to_delete:
        usernames = [user[0] for user in users_to_delete]
        placeholders = ','.join('?' for _ in usernames)
        query = f"DELETE FROM streak WHERE username IN ({placeholders})"

        # Execute the deletion query
        cursor.execute(query, usernames)
        print("Deleted users with zero points from streaks.")

    # Commit the transaction and close the connection
    conn.commit()
    conn.close()




def update_valid_time(username, real_time):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()

    # Retrieve the current time for the username
    cursor.execute('''SELECT time FROM users WHERE username = ?''', (username,))
    result = cursor.fetchone()

    if result:
        time = result[0]
        
        # Check if real_time is greater than time
        if real_time > time:
            # Update valid_time to 1
            cursor.execute('''UPDATE users 
                              SET valid_time = 1, real_time = ?
                              WHERE username = ?''', 
                              (real_time, username))
            conn.commit()
    
    conn.close()




from apscheduler.schedulers.background import BackgroundScheduler
scheduler = BackgroundScheduler()


def reset_real_time():
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''UPDATE users SET real_time = 0''')
    conn.commit()
    conn.close()

# Schedule the reset_real_time function to run daily at midnight
scheduler.add_job(reset_real_time, 'cron', hour=0, minute=0)
scheduler.start()



@app.post("/kids/v2/screen-time/")
async def update_valid_time(request: Request):
    # Extract username and real_time from query parameters
    username = request.query_params.get("username")
    new_real_time = request.query_params.get("real_time")

    if username and new_real_time:
        conn = sqlite3.connect('kids_chat.db')
        cursor = conn.cursor()

        # Convert new_real_time to integer
        new_real_time = int(new_real_time)

        # Retrieve the current time and real_time for the username
        cursor.execute('''SELECT time, real_time FROM users WHERE username = ?''', (username,))
        result = cursor.fetchone()

        if result:
            time, current_real_time = result


            # Calculate the new total real_time
            total_real_time = current_real_time + new_real_time

            # Determine if total_real_time is greater than the stored time
            if total_real_time > time:
                # Update valid_time to 1 and store the new total_real_time
                cursor.execute('''UPDATE users 
                                  SET valid_time = 1, real_time = ?
                                  WHERE username = ?''', 
                                  (total_real_time, username))
            else:
                # Just update the real_time without changing valid_time
                cursor.execute('''UPDATE users 
                                  SET real_time = ?, valid_time = 0
                                  WHERE username = ?''', 
                                  (total_real_time, username))

            conn.commit()

        conn.close()
        return {"status": "success", "message": "valid_time and real_time updated"}
    else:
        return {"status": "error", "message": "Missing username or real_time"}



class ProfileTime(BaseModel):
    time: int


def update_screentime(username: str, time: str):
    conn = sqlite3.connect('kids_chat.db')
    cursor = conn.cursor()
    cursor.execute('''UPDATE users
                      SET time = ?
                      WHERE username = ?''',
                   (time, username))
    conn.commit()
    conn.close()

@app.put("/kids/v2/update-profiletime/")
def update_user_Time(username: str, profile: ProfileTime):
    try:
        update_screentime(username, profile.time,)
        return {"message": "Time updated successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))







if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
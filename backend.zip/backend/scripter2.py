# import boto3

# # Initialize Polly client
# polly_client = boto3.Session(
#                 aws_access_key_id='AKIA4JJHQBORKLVC7W5B',
#                 aws_secret_access_key='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',
#                 region_name='us-west-2').client('polly')

# # Define the text to be converted to speech
# story = """
# <speak>
#     <prosody rate='medium'>
#     In a small village, a kind fox named Felix loved helping his friends.
#     One day, Felix saw a bird trapped in a net. He wasted no time and freed the bird with his sharp teeth.
 
#         “Thank you, Felix!” chirped the little bird happily.
#         Felix smiled and replied, “Helping others makes us all happy.”
#         From that day on, the animals in the village helped each other whenever they could. 
#         They learned that kindness and helping make their world a better place.
#         The lesson: Always help others; it spreads happiness and makes you feel good.
#     </prosody>
# </speak>
# """

# # Convert text to speech using Amazon Polly
# response = polly_client.synthesize_speech(
#     Text=story,
#     OutputFormat='mp3',
#     VoiceId='Ivy',  # Use a British English voice
#     Engine='neural',  # Use the neural engine for better quality
#     TextType='ssml'   # Specify that the text is in SSML format
# )

# # Save the audio file
# with open('story.mp3', 'wb') as file:
#     file.write(response['AudioStream'].read())

# print("Audio file generated successfully!")


# import boto3

# # Initialize Polly client
# polly_client = boto3.Session(
#                 aws_access_key_id='AKIA4JJHQBORKLVC7W5B',
#                 aws_secret_access_key='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',
#                 region_name='us-west-2').client('polly')

# # Define the text to be converted to speech with excitement using simplified SSML
# story = """
# <speak>
#     <prosody rate='fast' pitch='+20%'>
#     In a small village, a kind fox named Felix loved helping his friends.
#     One day, Felix saw a bird trapped in a net. He wasted no time and freed the bird with his sharp teeth.
#     “Thank you, Felix!” chirped the little bird happily.
#     Felix smiled and replied, “Helping others makes us all happy.”
#     From that day on, the animals in the village helped each other whenever they could. 
#     They learned that kindness and helping make their world a better place.
#     The lesson: Always help others; it spreads happiness and makes you feel good.
#     </prosody>
# </speak>
# """

# # Convert text to speech using Amazon Polly
# response = polly_client.synthesize_speech(
#     Text=story,
#     OutputFormat='mp3',
#     VoiceId='Ivy',  # Use the American English voice Ivy
#     Engine='neural',  # Use the neural engine for better quality
#     TextType='ssml'   # Specify that the text is in SSML format
# )

# # Save the audio file
# with open('story.mp3', 'wb') as file:
#     file.write(response['AudioStream'].read())

# print("Audio file generated successfully!")


















# from apscheduler.schedulers.background import BackgroundScheduler
# from datetime import datetime
# from aviFlowai3 import generate_story, generate_url, save_story_to_database, get_daily_topic2, generate_video_from_story, update_video_path_in_database,check_if_story_exists
# import sqlite3

# def generate_and_save_story_for_age_group(age_group, today):
#     topic = get_daily_topic2()  # Get the daily topic
#     age_group_mapping = {
#         "5-6": 5,
#         "7-8": 7,
#         "9-11": 9
#     }
#     age = age_group_mapping[age_group]  # Map age group to representative age
    
#     # Generate story and image
#     story = generate_story(age, topic)
#     image_url = generate_url(story)
    
#     # Save story and image to database
#     save_story_to_database(today, age_group, story, image_url)
    
#     # Generate and save the video
#     video_path = generate_video_from_story(story, age_group)
#     update_video_path_in_database(today, age_group, video_path)

#     print(f"Story for age group {age_group} saved successfully.")

# def generate_story_for_all_age_groups():
#     today = datetime.today().strftime('%Y-%m-%d')
#     age_groups = ["5-6", "7-8", "9-11"]

#     for age_group in age_groups:
#         # Check if the story already exists for today
#         if not check_if_story_exists(today, age_group):
#             generate_and_save_story_for_age_group(age_group, today)

# # Set up the scheduler to run the job every day at midnight
# scheduler = BackgroundScheduler()

# # Schedule the job to run at midnight (12:00 AM) every day
# scheduler.add_job(generate_story_for_all_age_groups, 'cron', hour=18, minute=39)

# # Start the scheduler
# scheduler.start()

# # Keep the script running
# try:
#     while True:
#         pass
# except (KeyboardInterrupt, SystemExit):
#     scheduler.shutdown()












from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
from main2 import (
    generate_story, generate_url, save_story_to_database, get_daily_topic2, get_kid_name,
    generate_video_from_story, update_video_path_in_database, check_if_story_exists
)
import sqlite3
story_generated_successfully = False

def generate_and_save_story_for_age_group(age_group, today):
    global story_generated_successfully
    try:
        topic = get_daily_topic2() 
        name= get_kid_name() 
        print("story topic" ,topic)
        age_group_mapping = {
            "5-6": 5,
            "7-8": 7,
            "9-11": 9
        }
        age = age_group_mapping[age_group]  

        story = generate_story(age, topic,name)
        image_url = generate_url(story)
        save_story_to_database(today, age_group, story, image_url)


        video_path = generate_video_from_story(story, age_group)
        update_video_path_in_database(today, age_group, video_path)

        print(f"Story for age group {age_group} saved successfully.")
        story_generated_successfully = True  

    except Exception as e:
        print(f"Error generating story for age group {age_group}: {e}")
        story_generated_successfully = False  

def generate_story_for_all_age_groups():
    today = datetime.today().strftime('%Y-%m-%d')
    age_groups = ["5-6", "7-8", "9-11"]
    global story_generated_successfully

    for age_group in age_groups:
        
        if not check_if_story_exists(today, age_group):
            generate_and_save_story_for_age_group(age_group, today)

    
    if not story_generated_successfully:
        print("Story generation failed for some age groups. Scheduling retry at 2 AM.")
        scheduler.add_job(retry_story_generation, 'cron', hour=11, minute=30)

def retry_story_generation():
    print("Retrying story generation at 2 AM...")
    generate_story_for_all_age_groups()


scheduler = BackgroundScheduler()


scheduler.add_job(generate_story_for_all_age_groups, 'cron', hour=11, minute=57)


scheduler.start()

try:
    while True:
        pass
except (KeyboardInterrupt, SystemExit):
    scheduler.shutdown()
